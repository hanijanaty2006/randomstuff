import { useEffect, useMemo, useState } from 'react';
import clsx from 'clsx';
import { chunk } from 'lodash-es';
import { HexColorInput, HexColorPicker } from 'react-colorful';
import { ArrowLeft, Code2, Cpu, Download, Eraser, Palette, Sparkles, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { downloadBytes } from '../lib/exporters';
import { generateCHR } from '../lib/nes';
import { nearestNesColor } from '../lib/nesPalette';
import { useStudio } from '../store/useStudio';
import type { Project } from '../types';
import { TileSwatch } from './LevelEditor';

export const SpriteWorkshop = ({ project }: { project: Project }) => {
  const selectedTileId = useStudio((s) => s.selectedTile);
  const paletteSlot = useStudio((s) => s.paletteSlot);
  const setSelectedTile = useStudio((s) => s.setSelectedTile);
  const setPaletteSlot = useStudio((s) => s.setPaletteSlot);
  const setTilePixel = useStudio((s) => s.setTilePixel);
  const setPaletteColor = useStudio((s) => s.setPaletteColor);
  const setTileMeta = useStudio((s) => s.setTileMeta);
  const clearTile = useStudio((s) => s.clearTile);
  const setTab = useStudio((s) => s.setTab);
  const [painting, setPainting] = useState(false);
  const tile = project.tiles[selectedTileId];
  const base = tile.palette * 4;
  const activeColor = project.palette[base + paletteSlot] ?? '#000000';
  const chr = useMemo(() => generateCHR(project), [project]);
  const chrRows = chunk([...chr.slice(selectedTileId * 16, selectedTileId * 16 + 16)], 8);
  const hardware = nearestNesColor(activeColor);

  useEffect(() => {
    const stop = () => setPainting(false);
    window.addEventListener('mouseup', stop);
    return () => window.removeEventListener('mouseup', stop);
  }, []);

  return (
    <div className="sprite-workshop">
      <aside className="sprite-list">
        <div className="panel-heading"><Sparkles size={13} /> PATTERN TABLE $0000</div>
        <div className="sprite-list-scroll">
          {project.tiles.map((item) => (
            <button key={item.id} className={clsx('sprite-list-item', item.id === selectedTileId && 'selected')} onClick={() => setSelectedTile(item.id)}>
              <TileSwatch tile={item} palette={project.palette} size={28} />
              <div><b>{item.name}</b><small>CHR ${item.id.toString(16).toUpperCase().padStart(2, '0')} · PAL {item.palette}</small></div>
            </button>
          ))}
        </div>
        <button className="win-button wide" onClick={() => setTab('level')}><ArrowLeft size={12} /> Back to Level</button>
      </aside>

      <section className="pixel-lab">
        <div className="lab-heading">
          <div><span className="eyebrow">PIXEL WORKSHOP</span><h2>{tile.name}</h2></div>
          <div className="lab-actions">
            <button className="win-button" onClick={() => clearTile(selectedTileId)}><Trash2 size={12} /> Clear</button>
            <button className="win-button" onClick={() => { downloadBytes(generateCHR(project), `${project.name.toLowerCase().replace(/\s+/g, '-')}.chr.bin`); toast.success('CHR-ROM exported'); }}><Download size={12} /> Export CHR</button>
          </div>
        </div>
        <div className="pixel-lab-body">
          <div className="pixel-editor-wrap">
            <div className="pixel-screen">
              <div className="pixel-grid" onMouseLeave={() => setPainting(false)}>
                {Array.from({ length: 64 }, (_, i) => {
                  const value = tile.pattern[i] ?? 0;
                  return (
                    <button
                      key={i}
                      className={clsx('pixel-cell', value === 0 && 'transparent')}
                      style={value ? { background: project.palette[base + value] } : undefined}
                      title={`(${i % 8},${Math.floor(i / 8)}) = ${value}`}
                      onMouseDown={(e) => { e.preventDefault(); setPainting(true); setTilePixel(selectedTileId, i, e.button === 2 ? 0 : paletteSlot); }}
                      onMouseEnter={() => { if (painting) setTilePixel(selectedTileId, i, paletteSlot); }}
                      onContextMenu={(e) => { e.preventDefault(); setTilePixel(selectedTileId, i, 0); }}
                    />
                  );
                })}
              </div>
            </div>
            <div className="pixel-legend"><Eraser size={12} /> Right-click a pixel to erase · drag to paint · 8×8 / 2 bits per pixel</div>
            <div className="tile-meta">
              <label className="field-label">Tile name</label>
              <input className="win-input" value={tile.name} onChange={(e) => setTileMeta(selectedTileId, { name: e.target.value })} />
              <div className="compact-grid two">
                <label className="checkbox-row"><input type="checkbox" checked={tile.solid} onChange={(e) => setTileMeta(selectedTileId, { solid: e.target.checked })} /> Solid</label>
                <label className="checkbox-row"><input type="checkbox" checked={tile.hazard} onChange={(e) => setTileMeta(selectedTileId, { hazard: e.target.checked })} /> Hazard</label>
              </div>
              <label className="field-label">Palette bank</label>
              <select className="win-select" value={tile.palette} onChange={(e) => setTileMeta(selectedTileId, { palette: Number(e.target.value) })}>
                {[0, 1, 2, 3].map((i) => <option key={i} value={i}>Palette {i}</option>)}
              </select>
            </div>
          </div>

          <aside className="palette-lab">
            <div className="panel-heading"><Palette size={13} /> PPU PALETTE {tile.palette}</div>
            <div className="color-slots">
              {[0, 1, 2, 3].map((slot) => (
                <button key={slot} className={clsx('color-slot', paletteSlot === slot && 'selected')} onClick={() => setPaletteSlot(slot)}>
                  <span style={{ background: project.palette[base + slot] }} />
                  <small>{slot}{slot === 0 ? ' · BG' : ''}</small>
                </button>
              ))}
            </div>
            <div className="color-picker-wrap">
              <HexColorPicker color={activeColor} onChange={(color) => setPaletteColor(base + paletteSlot, color)} />
              <div className="hex-row"><span>HEX</span><HexColorInput color={activeColor} onChange={(color) => setPaletteColor(base + paletteSlot, color)} prefixed /></div>
              <div className="hardware-note"><Cpu size={12} /> 2C02 nearest: <b>${hardware.index.toString(16).toUpperCase().padStart(2, '0')}</b><span className="nes-chip" style={{ background: hardware.hex }} /> {hardware.hex}</div>
            </div>
            <div className="chr-panel">
              <div className="panel-heading"><Code2 size={13} /> CHR BITPLANES · 16 BYTES</div>
              <pre>{chrRows.map((row, i) => `${i === 0 ? 'LOW ' : 'HIGH'}  ${row.map((v) => v.toString(16).toUpperCase().padStart(2, '0')).join(' ')}`).join('\n')}</pre>
              <small>Each 8×8 tile is encoded as two 1bpp planes and packed into pattern table $0000.</small>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
};
