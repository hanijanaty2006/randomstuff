import { useEffect, useRef, useState, type ReactNode } from 'react';
import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ChevronDown, Cpu, Download, Eraser, Eye, FolderOpen, Gamepad2, Grid3X3, Hammer,
  HelpCircle, Minus, Monitor, Package, PaintBucket, Paintbrush, Play, RotateCcw,
  RotateCw, Save, Square, UserPlus, Volume2, X, ZoomIn, ZoomOut, MousePointer2,
} from 'lucide-react';
import { useStudio } from '../store/useStudio';
import { playSfx } from '../lib/audio';

export interface MenuAction {
  label: string;
  shortcut?: string;
  action?: () => void;
  separator?: boolean;
  disabled?: boolean;
}
export interface MenuGroup { label: string; items: MenuAction[] }

export const TitleBar = ({ maximized, onMaximize, onMinimize, onClose }: {
  maximized: boolean;
  onMaximize: () => void;
  onMinimize: () => void;
  onClose: () => void;
}) => {
  const name = useStudio((s) => s.project.name);
  return (
    <div className="title-bar app-title-bar" onDoubleClick={onMaximize}>
      <div className="title-bar-text"><Cpu size={14} className="title-icon" /> NES MAKER STUDIO 98 — {name}</div>
      <div className="title-bar-controls">
        <button title="Minimize" onClick={onMinimize}><Minus size={10} /></button>
        <button title={maximized ? 'Restore' : 'Maximize'} onClick={onMaximize}><Square size={9} /></button>
        <button title="Close" className="close-button" onClick={onClose}><X size={11} /></button>
      </div>
    </div>
  );
};

export const MenuBar = ({ groups }: { groups: MenuGroup[] }) => {
  const [open, setOpen] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(null);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);
  return (
    <div className="menu-bar" ref={ref}>
      {groups.map((group) => (
        <div className="menu-host" key={group.label}>
          <button className={clsx('menu-trigger', open === group.label && 'open')} onClick={() => setOpen(open === group.label ? null : group.label)}>
            <span>{group.label}</span>
          </button>
          {open === group.label && (
            <div className="menu-popup">
              {group.items.map((item, index) => item.separator ? (
                <div className="menu-separator" key={`sep-${index}`} />
              ) : (
                <button key={item.label} className="menu-item" disabled={item.disabled} onClick={() => {
                  setOpen(null);
                  playSfx('click');
                  item.action?.();
                }}>
                  <span>{item.label}</span><span className="shortcut">{item.shortcut ?? ''}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

const ToolButton = ({ active, title, icon, onClick, disabled, badge }: {
  active?: boolean; title: string; icon: ReactNode; onClick: () => void; disabled?: boolean; badge?: boolean;
}) => (
  <button className={clsx('tool-button', active && 'active')} title={title} disabled={disabled} onClick={onClick}>
    {icon}
    {badge && <span className="tool-badge" />}
  </button>
);

export const Toolbar = ({ onAction }: { onAction: (action: string) => void }) => {
  const tool = useStudio((s) => s.tool);
  const showGrid = useStudio((s) => s.showGrid);
  const showCollision = useStudio((s) => s.showCollision);
  const zoom = useStudio((s) => s.zoom);
  const canUndo = useStudio((s) => s.past.length > 0);
  const canRedo = useStudio((s) => s.future.length > 0);
  const needsBuild = useStudio((s) => s.needsBuild);
  const setTool = useStudio((s) => s.setTool);
  const toggleGrid = useStudio((s) => s.toggleGrid);
  const toggleCollision = useStudio((s) => s.toggleCollision);
  const setZoom = useStudio((s) => s.setZoom);
  const undo = useStudio((s) => s.undo);
  const redo = useStudio((s) => s.redo);
  const click = (fn: () => void) => { playSfx('click'); fn(); };

  return (
    <div className="toolbar">
      <div className="tool-group">
        <ToolButton title="New cartridge" icon={<Package size={17} />} onClick={() => onAction('new')} />
        <ToolButton title="Open project JSON" icon={<FolderOpen size={17} />} onClick={() => onAction('open')} />
        <ToolButton title="Save project / export JSON" icon={<Save size={17} />} onClick={() => onAction('save')} />
      </div>
      <div className="toolbar-divider" />
      <div className="tool-group">
        <ToolButton title="Undo (Ctrl+Z)" icon={<RotateCcw size={16} />} disabled={!canUndo} onClick={() => click(undo)} />
        <ToolButton title="Redo (Ctrl+Y)" icon={<RotateCw size={16} />} disabled={!canRedo} onClick={() => click(redo)} />
      </div>
      <div className="toolbar-divider" />
      <div className="tool-group">
        <ToolButton title="Select / move entity (V)" icon={<MousePointer2 size={16} />} active={tool === 'select'} onClick={() => click(() => setTool('select'))} />
        <ToolButton title="Brush (B)" icon={<Paintbrush size={16} />} active={tool === 'brush'} onClick={() => click(() => setTool('brush'))} />
        <ToolButton title="Eraser (E)" icon={<Eraser size={16} />} active={tool === 'eraser'} onClick={() => click(() => setTool('eraser'))} />
        <ToolButton title="Flood fill (F)" icon={<PaintBucket size={16} />} active={tool === 'fill'} onClick={() => click(() => setTool('fill'))} />
        <ToolButton title="Rectangle fill (R)" icon={<Square size={15} />} active={tool === 'rect'} onClick={() => click(() => setTool('rect'))} />
        <ToolButton title="Place entity (D)" icon={<UserPlus size={16} />} active={tool === 'entity'} onClick={() => click(() => setTool('entity'))} />
      </div>
      <div className="toolbar-divider" />
      <div className="tool-group">
        <ToolButton title="Toggle tile grid (G)" icon={<Grid3X3 size={16} />} active={showGrid} onClick={() => click(toggleGrid)} />
        <ToolButton title="Toggle collision overlay" icon={<Eye size={16} />} active={showCollision} onClick={() => click(toggleCollision)} />
        <ToolButton title="Zoom out" icon={<ZoomOut size={16} />} disabled={zoom <= 1} onClick={() => click(() => setZoom(zoom - 1))} />
        <span className="zoom-label">{zoom}×</span>
        <ToolButton title="Zoom in" icon={<ZoomIn size={16} />} disabled={zoom >= 4} onClick={() => click(() => setZoom(zoom + 1))} />
      </div>
      <div className="toolbar-spacer" />
      <div className="toolbar-label">BUILD TARGET</div>
      <button className="toolbar-action primary" onClick={() => onAction('build')}>
        <Hammer size={15} /> BUILD CARTRIDGE {needsBuild && <span className="build-dot" />}
      </button>
      <button className="toolbar-action" onClick={() => onAction('preview')}><Play size={14} /> HTML5</button>
      <button className="toolbar-action" onClick={() => onAction('emulator')}><Gamepad2 size={15} /> NES</button>
      <button className="toolbar-action" onClick={() => onAction('zip')}><Download size={15} /> DEV KIT</button>
      <ToolButton title="Help (F1)" icon={<HelpCircle size={17} />} onClick={() => onAction('help')} />
    </div>
  );
};

export const StatusBar = () => {
  const status = useStudio((s) => s.statusMessage);
  const hover = useStudio((s) => s.hover);
  const tool = useStudio((s) => s.tool);
  const tile = useStudio((s) => s.selectedTile);
  const zoom = useStudio((s) => s.zoom);
  const entityCount = useStudio((s) => s.project.entities.length);
  const dirty = useStudio((s) => s.dirty);
  const needsBuild = useStudio((s) => s.needsBuild);
  const lastSavedAt = useStudio((s) => s.lastSavedAt);
  return (
    <div className="status-bar">
      <div className="status-field status-main"><span className="status-led green" />{status}</div>
      <div className="status-field">X:{String(hover?.x ?? 0).padStart(2, '0')} Y:{String(hover?.y ?? 0).padStart(2, '0')}</div>
      <div className="status-field">{tool.toUpperCase()} · TILE {tile.toString(16).toUpperCase().padStart(2, '0')} · {entityCount} OBJ</div>
      <div className="status-field">ZOOM {zoom}×</div>
      <div className="status-field">{dirty ? 'MODIFIED' : lastSavedAt ? 'SAVED' : 'CLEAN'}</div>
      <div className="status-field"><span className={clsx('status-led', needsBuild ? 'amber' : 'green')} />{needsBuild ? 'REBUILD REQUIRED' : 'ROM READY'}</div>
    </div>
  );
};

export interface TaskbarActions {
  restore: () => void;
  newProject: () => void;
  build: () => void;
  preview: () => void;
  emulator: () => void;
  about: () => void;
  help: () => void;
}

export const Taskbar = ({ actions, windowVisible }: { actions: TaskbarActions; windowVisible: boolean }) => {
  const [showStart, setShowStart] = useState(false);
  const [now, setNow] = useState(new Date());
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    const close = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setShowStart(false);
    };
    document.addEventListener('mousedown', close);
    return () => { window.clearInterval(timer); document.removeEventListener('mousedown', close); };
  }, []);
  const item = (label: string, action: () => void) => (
    <button className="start-menu-item" onClick={() => { setShowStart(false); playSfx('click'); action(); }}>{label}</button>
  );
  return (
    <div className="taskbar" ref={ref}>
      <button className={clsx('start-button', showStart && 'active')} onClick={() => { playSfx('click'); setShowStart(!showStart); }}>
        <span className="start-logo">▦</span> Start <ChevronDown size={11} />
      </button>
      <AnimatePresence>
        {showStart && (
          <motion.div className="start-menu" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} transition={{ duration: 0.13 }}>
            <div className="start-brand">Windows <b>98</b><small> NES DEV EDITION</small></div>
            <div className="start-menu-list">
              {item('▣  New Cartridge', actions.newProject)}
              {item('⚒  Build NES ROM', actions.build)}
              {item('▶  HTML5 Playground', actions.preview)}
              {item('🎮  Hardware Emulator', actions.emulator)}
              <div className="menu-separator" />
              {item('❔  Keyboard Shortcuts', actions.help)}
              {item('ℹ  About NES Maker Studio', actions.about)}
              <div className="menu-separator" />
              {item('▤  Restore Studio Window', actions.restore)}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="taskbar-divider" />
      <button className={clsx('task-chip', windowVisible && 'active')} onClick={actions.restore}><Cpu size={13} /> NES Maker Studio 98</button>
      <button className="task-chip" onClick={() => { useStudio.getState().setTab('source'); actions.restore(); }}><Monitor size={13} /> Build Monitor</button>
      <div className="taskbar-spacer" />
      <div className="tray"><Volume2 size={13} /><Cpu size={13} /><span>{now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}</span></div>
    </div>
  );
};

export const DesktopIcons = ({ onOpen }: { onOpen: (tab: string) => void }) => (
  <div className="desktop-icons">
    {[
      { label: 'My Computer', icon: '🖥️', tab: 'rom' },
      { label: 'NES ROMs', icon: '🎮', tab: 'emulator' },
      { label: 'HTML5 Builds', icon: '🌐', tab: 'preview' },
      { label: 'Source Files', icon: '📄', tab: 'source' },
      { label: 'Recycle Bin', icon: '🗑️', tab: 'level' },
    ].map((icon) => (
      <button key={icon.label} className="desktop-icon" onDoubleClick={() => onOpen(icon.tab)} onClick={() => playSfx('click')}>
        <span>{icon.icon}</span><small>{icon.label}</small>
      </button>
    ))}
  </div>
);
