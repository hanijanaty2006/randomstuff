import { useEffect, useState, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { nanoid } from 'nanoid';
import { toast } from 'sonner';
import { Box, CheckCircle2, Cpu, FolderOpen, Info, Save, Settings, Trash2, X } from 'lucide-react';
import { deleteFromLibrary, getFromLibrary, listLibrary, saveToLibrary } from '../lib/storage';
import { playSfx } from '../lib/audio';
import { useStudio } from '../store/useStudio';
import type { Project, SaveSlot } from '../types';

const WinDialog = ({ title, icon, children, width = 620 }: { title: string; icon: ReactNode; children: ReactNode; width?: number }) => {
  const setDialog = useStudio((s) => s.setDialog);
  return (
    <motion.div className="dialog-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.12 }} onMouseDown={(e) => { if (e.target === e.currentTarget) setDialog(null); }}>
      <motion.div className="window dialog-window" style={{ width }} initial={{ scale: 0.94, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.96, y: 8 }} transition={{ duration: 0.14 }}>
        <div className="title-bar">
          <div className="title-bar-text">{icon} {title}</div>
          <div className="title-bar-controls"><button onClick={() => setDialog(null)}><X size={11} /></button></div>
        </div>
        <div className="window-body dialog-body">{children}</div>
      </motion.div>
    </motion.div>
  );
};

const AboutDialog = () => (
  <div className="about-dialog">
    <div className="about-hero">
      <div className="about-logo"><Cpu size={38} /></div>
      <div><span className="eyebrow">VERSION 1.0 · BUILD 1998</span><h2>NES MAKER STUDIO 98</h2><p>A genuine cross-compiler workstation for 2D platformers: author a level once, then ship a real NROM-256 cartridge and a self-contained HTML5 game.</p></div>
    </div>
    <div className="about-features">
      <div><CheckCircle2 size={14} /> Two-pass 6502 assembler</div>
      <div><CheckCircle2 size={14} /> 2bpp CHR encoder</div>
      <div><CheckCircle2 size={14} /> PPU nametable builder</div>
      <div><CheckCircle2 size={14} /> jsnes hardware test</div>
      <div><CheckCircle2 size={14} /> HTML5 physics runtime</div>
      <div><CheckCircle2 size={14} /> ZIP development kit</div>
    </div>
    <div className="panel-heading"><Box size={13} /> THIRD-PARTY POWER GRID</div>
    <div className="library-badges">
      {['98.css', 'Zustand', 'Immer', 'Konva', 'jsnes', 'Tone.js', 'JSZip', 'file-saver', 'Dexie', 'react-colorful', 'hotkeys-js', 'lucide-react', 'framer-motion', 'sonner', 'nanoid', 'lodash-es', 'Tailwind CSS'].map((name) => <span key={name}>{name}</span>)}
    </div>
    <div className="dialog-note"><Info size={13} /> The exported .nes file contains an iNES header, 32 KiB PRG-ROM, 8 KiB CHR-ROM, 6502 vectors and a hardware runtime — not a mockup or screenshot.</div>
  </div>
);

const HelpDialog = () => {
  const shortcuts = [
    ['B', 'Brush tool'], ['E', 'Eraser'], ['F', 'Flood fill'], ['R', 'Rectangle fill'],
    ['V', 'Select / move entity'], ['D', 'Entity placement'], ['G', 'Toggle grid'], ['1–4', 'Zoom level'],
    ['Ctrl+Z / Y', 'Undo / redo'], ['Ctrl+S', 'Download project JSON'], ['F5', 'HTML5 playtest'], ['F6', 'Build cartridge'],
  ];
  return (
    <div className="help-dialog">
      <div className="panel-heading"><Info size={13} /> KEYBOARD SHORTCUTS</div>
      <div className="shortcut-grid">{shortcuts.map(([key, label]) => <div key={key}><kbd>{key}</kbd><span>{label}</span></div>)}</div>
      <div className="panel-heading"><CheckCircle2 size={13} /> WORKFLOW</div>
      <ol>
        <li>Paint the 32×30 nametable and place player, enemies, coins and a goal.</li>
        <li>Use the Pixel Workshop to edit 8×8 CHR tiles and hardware palettes.</li>
        <li>Click <b>BUILD CARTRIDGE</b> to assemble source, CHR, palettes and vectors.</li>
        <li>Boot the exact ROM in the jsnes tab or export .nes / .html / dev kit.</li>
      </ol>
      <div className="dialog-note">NES controls: D-Pad left/right, A / B / Up to jump. HTML5: arrows or A/D, Space / Z / W / Up, R to restart.</div>
    </div>
  );
};

const SettingsDialog = () => {
  const project = useStudio((s) => s.project);
  const updateProject = useStudio((s) => s.updateProject);
  const setDialog = useStudio((s) => s.setDialog);
  const resetProject = useStudio((s) => s.resetProject);
  const [draft, setDraft] = useState(() => ({
    name: project.name, author: project.author, description: project.description, target: project.target,
    gravity: project.gravity, speed: project.speed, jump: project.jump, lives: project.lives, timeLimit: project.timeLimit,
  }));
  const field = (key: keyof typeof draft, label: string, type: 'text' | 'number' = 'text', step = 0.01) => (
    <label className="settings-field" key={key}><span>{label}</span><input className="win-input" type={type} step={step} value={draft[key] as string | number} onChange={(e) => setDraft({ ...draft, [key]: type === 'number' ? Number(e.target.value) : e.target.value })} /></label>
  );
  return (
    <div className="settings-dialog">
      <div className="settings-grid">
        {field('name', 'Cartridge name')}
        {field('author', 'Author')}
        {field('description', 'Description')}
        <label className="settings-field"><span>Build target</span><select className="win-select" value={draft.target} onChange={(e) => setDraft({ ...draft, target: e.target.value as Project['target'] })}><option>Dual target</option><option>NES</option><option>HTML5</option></select></label>
        {field('gravity', 'Gravity / frame²', 'number')}
        {field('speed', 'Run speed / frame', 'number')}
        {field('jump', 'Jump impulse', 'number')}
        {field('lives', 'Lives', 'number', 1)}
        {field('timeLimit', 'Time limit (s)', 'number', 1)}
      </div>
      <div className="dialog-footer">
        <button className="win-button" onClick={() => { resetProject(); setDialog(null); toast.info('Demo project restored'); }}>Restore demo</button>
        <div className="spacer" />
        <button className="win-button" onClick={() => setDialog(null)}>Cancel</button>
        <button className="win-button primary" onClick={() => { updateProject(draft); setDialog(null); playSfx('success'); toast.success('Game settings updated'); }}><Save size={12} /> Apply</button>
      </div>
    </div>
  );
};

const LibraryDialog = () => {
  const project = useStudio((s) => s.project);
  const replaceProject = useStudio((s) => s.replaceProject);
  const markSaved = useStudio((s) => s.markSaved);
  const setDialog = useStudio((s) => s.setDialog);
  const [slots, setSlots] = useState<SaveSlot[]>([]);
  const [slotName, setSlotName] = useState(project.name);
  const [busy, setBusy] = useState(false);
  const refresh = async () => {
    try { setSlots(await listLibrary()); } catch { toast.error('IndexedDB library unavailable'); }
  };
  useEffect(() => { void refresh(); }, []);
  const save = async () => {
    setBusy(true);
    try {
      const named = { ...project, name: slotName || project.name };
      await saveToLibrary(nanoid(8), named);
      markSaved(); playSfx('success'); toast.success('Saved to local cartridge library');
      await refresh();
    } catch { toast.error('Could not save to IndexedDB'); } finally { setBusy(false); }
  };
  return (
    <div className="library-dialog">
      <div className="library-save-row">
        <div><b>Save current cartridge</b><small>Dexie / IndexedDB · stored locally in this browser</small></div>
        <input className="win-input" value={slotName} onChange={(e) => setSlotName(e.target.value)} placeholder="Cartridge name" />
        <button className="win-button primary" disabled={busy} onClick={save}><Save size={12} /> Save</button>
      </div>
      <div className="panel-heading"><FolderOpen size={13} /> LOCAL CARTRIDGE LIBRARY</div>
      <div className="library-list">
        {slots.length === 0 && <div className="empty-note">No saved cartridges yet. Save one to begin.</div>}
        {slots.map((slot) => (
          <div className="library-row" key={slot.id}>
            <div><b>{slot.name}</b><small>{new Date(slot.updatedAt).toLocaleString()} · {slot.data.entities.length} objects</small></div>
            <button className="win-button" onClick={async () => { const found = await getFromLibrary(slot.id); if (found) { replaceProject(found.data); setDialog(null); toast.success(`Loaded ${found.name}`); playSfx('success'); } }}><FolderOpen size={12} /> Load</button>
            <button className="win-button danger" onClick={async () => { await deleteFromLibrary(slot.id); await refresh(); toast.info('Slot deleted'); }}><Trash2 size={12} /></button>
          </div>
        ))}
      </div>
    </div>
  );
};

const NewDialog = () => {
  const newProject = useStudio((s) => s.newProject);
  const resetProject = useStudio((s) => s.resetProject);
  const setDialog = useStudio((s) => s.setDialog);
  return (
    <div className="new-dialog">
      <div className="about-hero compact"><div className="about-logo"><Box size={30} /></div><div><h2>New Cartridge</h2><p>Current unsaved changes will be replaced. Use Save Project JSON first if you want to keep them.</p></div></div>
      <div className="new-choices">
        <button className="choice-card" onClick={() => { newProject(); setDialog(null); toast.success('Blank cartridge created'); playSfx('click'); }}><b>Blank Cartridge</b><small>Floor tiles, one player spawn and a goal flag.</small></button>
        <button className="choice-card" onClick={() => { resetProject(); setDialog(null); toast.success('Demo level restored'); playSfx('click'); }}><b>Demo Level 1-1</b><small>Restore the full platformer sample with coins and enemies.</small></button>
      </div>
    </div>
  );
};

export const Dialogs = () => {
  const dialog = useStudio((s) => s.dialog);
  return (
    <AnimatePresence>
      {dialog === 'about' && <WinDialog key="about" title="About NES Maker Studio 98" icon={<Info size={13} />} width={680}><AboutDialog /></WinDialog>}
      {dialog === 'help' && <WinDialog key="help" title="Keyboard Shortcuts & Help" icon={<Info size={13} />} width={620}><HelpDialog /></WinDialog>}
      {dialog === 'settings' && <WinDialog key="settings" title="Game Properties" icon={<Settings size={13} />} width={620}><SettingsDialog /></WinDialog>}
      {dialog === 'library' && <WinDialog key="library" title="Cartridge Library" icon={<FolderOpen size={13} />} width={680}><LibraryDialog /></WinDialog>}
      {dialog === 'new' && <WinDialog key="new" title="New Cartridge" icon={<Box size={13} />} width={560}><NewDialog /></WinDialog>}
    </AnimatePresence>
  );
};
