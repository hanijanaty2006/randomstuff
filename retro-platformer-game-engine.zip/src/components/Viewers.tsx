import { useMemo, useState } from 'react';
import clsx from 'clsx';
import { chunk } from 'lodash-es';
import { toast } from 'sonner';
import { Cpu, Copy, FileCode2, Gamepad2, Hexagon, Layers, Search } from 'lucide-react';
import { generateStandaloneHTML } from '../lib/html5';
import { hexDump, type BuildResult } from '../lib/nes';
import { NES_PALETTE, rgbToHex } from '../lib/nesPalette';
import { useStudio } from '../store/useStudio';
import type { Project } from '../types';

type SourceMode = 'asm' | 'html' | 'json';

export const SourceViewer = ({ project, build }: { project: Project; build: BuildResult }) => {
  const [mode, setMode] = useState<SourceMode>('asm');
  const [filter, setFilter] = useState('');
  const source = useMemo(() => {
    if (mode === 'asm') return build.assembly;
    if (mode === 'html') return generateStandaloneHTML(project);
    return JSON.stringify(project, null, 2);
  }, [mode, project, build.assembly]);
  const lines = useMemo(() => source.split('\n').filter((line) => !filter || line.toLowerCase().includes(filter.toLowerCase())), [source, filter]);
  const copy = async () => {
    await navigator.clipboard.writeText(source);
    toast.success('Source copied to clipboard');
  };
  const lineClass = (line: string) => {
    if (mode !== 'asm') return 'code-normal';
    const trimmed = line.trim();
    if (trimmed.startsWith(';')) return 'code-comment';
    if (/^[A-Za-z_][\w]*:/.test(trimmed)) return 'code-label';
    if (trimmed.startsWith('.') || /^\s*\.byte/.test(trimmed)) return 'code-data';
    return 'code-normal';
  };
  return (
    <div className="source-viewer">
      <div className="viewer-toolbar">
        <div className="source-tabs">
          <button className={clsx(mode === 'asm' && 'active')} onClick={() => setMode('asm')}>engine.asm</button>
          <button className={clsx(mode === 'html' && 'active')} onClick={() => setMode('html')}>game.html</button>
          <button className={clsx(mode === 'json' && 'active')} onClick={() => setMode('json')}>project.json</button>
        </div>
        <div className="source-search"><Search size={12} /><input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filter lines..." /></div>
        <span className="source-count">{lines.length} lines · {(source.length / 1024).toFixed(1)} KiB</span>
        <button className="win-button" onClick={copy}><Copy size={12} /> Copy</button>
      </div>
      <div className="source-scroll">
        {lines.slice(0, 2200).map((line, index) => (
          <div className={clsx('code-line', lineClass(line))} key={`${index}-${line.slice(0, 8)}`}>
            <span className="line-number">{String(index + 1).padStart(4, '0')}</span><code>{line || ' '}</code>
          </div>
        ))}
        {lines.length > 2200 && <div className="source-truncated">… {lines.length - 2200} more lines omitted in preview; download the dev kit for the complete source.</div>}
      </div>
    </div>
  );
};

export const RomInspector = ({ project, build, canvases }: { project: Project; build: BuildResult; canvases: HTMLCanvasElement[] }) => {
  const setTab = useStudio((s) => s.setTab);
  const needsBuild = useStudio((s) => s.needsBuild);
  const symbols = build.assemblyResult.symbols;
  const paletteRows = chunk(build.palette, 16);
  const header = [
    ['Signature', '4E 45 53 1A', 'iNES magic'],
    ['PRG-ROM', '2 × 16 KiB', '$8000–$FFFF'],
    ['CHR-ROM', '1 × 8 KiB', '512 pattern slots'],
    ['Mapper', '0 · NROM-256', 'No bank switching'],
    ['Mirroring', 'Horizontal', 'Flags6 = $00'],
    ['TV system', 'NTSC', '60.0988 Hz'],
  ];
  return (
    <div className="rom-inspector">
      <div className="rom-hero">
        <div className="rom-hero-icon"><Cpu size={34} /></div>
        <div>
          <span className="eyebrow">iNES IMAGE INSPECTOR</span>
          <h2>{project.name.toUpperCase()}.NES</h2>
          <p>Assembled 6502 machine code, 2bpp pattern table, four PPU palettes, nametable and attribute map — a complete cartridge image.</p>
        </div>
        <div className="rom-hero-actions">
          {needsBuild && <div className="stale-banner">Project changed · rebuild for latest ROM</div>}
          <button className="win-button primary" onClick={() => setTab('emulator')}><Gamepad2 size={13} /> BOOT IN EMULATOR</button>
          <div className="checksum-box">FNV-1A <b>{build.checksum}</b></div>
        </div>
      </div>
      <div className="rom-grid">
        <section className="rom-card">
          <h3><Hexagon size={13} /> HEADER / MEMORY MAP</h3>
          <table className="rom-table"><tbody>{header.map(([a, b, c]) => <tr key={a}><td>{a}</td><td>{b}</td><td>{c}</td></tr>)}</tbody></table>
          <div className="vector-grid">
            <div><span>NMI</span><b>${(symbols.nmi ?? 0).toString(16).toUpperCase().padStart(4, '0')}</b></div>
            <div><span>RESET</span><b>${(symbols.reset ?? 0).toString(16).toUpperCase().padStart(4, '0')}</b></div>
            <div><span>IRQ</span><b>${(symbols.irq ?? 0).toString(16).toUpperCase().padStart(4, '0')}</b></div>
            <div><span>CODE</span><b>{build.assemblyResult.lineCount} stmts</b></div>
          </div>
        </section>
        <section className="rom-card">
          <h3><Layers size={13} /> CHR-ROM PREVIEW</h3>
          <div className="chr-sheet">
            {project.tiles.map((tile, i) => (
              <div className="chr-cell" key={tile.id} title={tile.name}>
                <img alt={tile.name} src={canvases[i]?.toDataURL('image/png')} />
                <small>{i.toString(16).toUpperCase()}</small>
              </div>
            ))}
          </div>
          <p className="card-note">Editing any pixel in the workshop re-encodes both bitplanes on the next build.</p>
        </section>
        <section className="rom-card">
          <h3><FileCode2 size={13} /> TRANSLATED 2C02 PALETTE</h3>
          {paletteRows.map((row, rowIndex) => (
            <div className="hardware-palette-row" key={rowIndex}>
              <span>{rowIndex === 0 ? 'BG ' : 'SPR'}</span>
              {row.map((index, i) => {
                const color = rgbToHex((NES_PALETTE[index] >> 16) & 255, (NES_PALETTE[index] >> 8) & 255, NES_PALETTE[index] & 255);
                return <div className="hardware-color" key={i} title={`$${index.toString(16).toUpperCase().padStart(2, '0')} · ${color}`} style={{ background: color }}>${index.toString(16).toUpperCase().padStart(2, '0')}</div>;
              })}
            </div>
          ))}
          <p className="card-note">Browser RGB values are quantized to the closest hardware color using a 64-entry 2C02 palette.</p>
        </section>
        <section className="rom-card wide-card">
          <h3><Hexagon size={13} /> FIRST 256 BYTES · HEADER + RESET CODE</h3>
          <pre className="hex-dump">{hexDump(build.rom, 0, 256)}</pre>
        </section>
      </div>
    </div>
  );
};
