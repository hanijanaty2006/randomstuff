import { useEffect, useMemo, useRef, useState } from 'react';
import clsx from 'clsx';
import Konva from 'konva';
import { Layers, MousePointer2, Move, Sparkles } from 'lucide-react';
import { ENTITY_LABEL, ENTITY_TILE } from '../data/project';
import { drawEntities, drawLevel } from '../lib/render';
import { useStudio } from '../store/useStudio';
import { LEVEL_H, LEVEL_W, SCREEN_H, SCREEN_W, TILE_SIZE, type Cell, type EntityKind, type Project, type TileDef } from '../types';

export const TileSwatch = ({ tile, palette, size = 32, className }: {
  tile: TileDef; palette: string[]; size?: number; className?: string;
}) => {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = 8;
    canvas.height = 8;
    ctx.clearRect(0, 0, 8, 8);
    const base = tile.palette * 4;
    for (let i = 0; i < 64; i++) {
      const value = tile.pattern[i] ?? 0;
      if (!value) continue;
      ctx.fillStyle = palette[base + value] ?? '#ffffff';
      ctx.fillRect(i % 8, Math.floor(i / 8), 1, 1);
    }
  }, [tile.pattern, tile.palette, palette]);
  return <canvas ref={ref} className={clsx('tile-swatch', className)} style={{ width: size, height: size }} />;
};

export const TilePalette = ({ project }: { project: Project }) => {
  const selectedTile = useStudio((s) => s.selectedTile);
  const selectedEntityKind = useStudio((s) => s.selectedEntityKind);
  const tool = useStudio((s) => s.tool);
  const setSelectedTile = useStudio((s) => s.setSelectedTile);
  const setSelectedEntityKind = useStudio((s) => s.setSelectedEntityKind);
  const setTool = useStudio((s) => s.setTool);
  const entityKinds: EntityKind[] = ['player', 'enemy', 'coin', 'power', 'goal'];
  return (
    <aside className="tile-palette">
      <div className="panel-heading"><Layers size={13} /> CHR BANK 0 · 16 TILES</div>
      <div className="tile-grid">
        {project.tiles.slice(0, 11).map((tile) => (
          <button key={tile.id} className={clsx('palette-tile', selectedTile === tile.id && tool !== 'entity' && 'selected')} title={`${tile.id}: ${tile.name}`} onClick={() => { setSelectedTile(tile.id); setTool('brush'); }}>
            <TileSwatch tile={tile} palette={project.palette} size={32} />
            <span className="tile-id">{tile.id.toString(16).toUpperCase()}</span>
          </button>
        ))}
      </div>
      <div className="panel-heading"><Sparkles size={13} /> OBJECTS / OAM</div>
      <div className="entity-list">
        {entityKinds.map((kind) => (
          <button key={kind} className={clsx('entity-button', tool === 'entity' && selectedEntityKind === kind && 'selected')} onClick={() => setSelectedEntityKind(kind)}>
            <TileSwatch tile={project.tiles[ENTITY_TILE[kind]]} palette={project.palette} size={24} />
            <span>{ENTITY_LABEL[kind]}</span>
          </button>
        ))}
      </div>
      <div className="palette-hint">
        <MousePointer2 size={12} /> Left-click paints · right-click removes<br />
        <Move size={12} /> Use SELECT to drag entities
      </div>
    </aside>
  );
};

interface RectPreview { start: Cell; end: Cell }

export const LevelCanvas = ({ project, canvases }: { project: Project; canvases: HTMLCanvasElement[] }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const layerRef = useRef<any>(null);
  const imageRef = useRef<any>(null);
  const sceneRef = useRef<HTMLCanvasElement | null>(null);
  const paintingRef = useRef(false);
  const rectRef = useRef<RectPreview | null>(null);
  const draggingEntityRef = useRef<string | null>(null);
  const [preview, setPreview] = useState<RectPreview | null>(null);
  const zoom = useStudio((s) => s.zoom);
  const showGrid = useStudio((s) => s.showGrid);
  const showCollision = useStudio((s) => s.showCollision);
  const hover = useStudio((s) => s.hover);
  const tool = useStudio((s) => s.tool);
  const selectedTile = useStudio((s) => s.selectedTile);
  const selectedEntityId = useStudio((s) => s.selectedEntityId);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const scene = document.createElement('canvas');
    sceneRef.current = scene;
    const stage = new Konva.Stage({ container, width: SCREEN_W * zoom, height: SCREEN_H * zoom });
    const layer = new Konva.Layer();
    const image = new Konva.Image({ image: scene as CanvasImageSource, x: 0, y: 0, width: SCREEN_W * zoom, height: SCREEN_H * zoom, listening: false });
    layer.add(image);
    stage.add(layer);
    layerRef.current = layer;
    imageRef.current = image;
    stage.container().style.cursor = 'crosshair';

    const cellAtPointer = (): Cell | null => {
      const pointer = stage.getPointerPosition();
      if (!pointer) return null;
      const x = Math.floor(pointer.x / zoom / TILE_SIZE);
      const y = Math.floor(pointer.y / zoom / TILE_SIZE);
      if (x < 0 || x >= LEVEL_W || y < 0 || y >= LEVEL_H) return null;
      return { x, y };
    };

    const applyBrush = (cell: Cell) => {
      const state = useStudio.getState();
      state.setLevelCells([cell], state.tool === 'eraser' ? 0 : state.selectedTile);
    };

    stage.on('mousedown touchstart', (event: any) => {
      const cell = cellAtPointer();
      if (!cell) return;
      const state = useStudio.getState();
      const native = event.evt as MouseEvent;
      state.setHover(cell);
      if (native?.button === 2) {
        const entityExists = state.project.entities.some((e) => e.x === cell.x && e.y === cell.y);
        if (entityExists) state.removeEntityAt(cell.x, cell.y);
        else state.setLevelCells([cell], 0);
        return;
      }
      if (state.tool === 'brush' || state.tool === 'eraser') {
        paintingRef.current = true;
        applyBrush(cell);
      } else if (state.tool === 'fill') {
        state.floodFill(cell.x, cell.y);
      } else if (state.tool === 'rect') {
        rectRef.current = { start: cell, end: cell };
        setPreview(rectRef.current);
      } else if (state.tool === 'entity') {
        state.addEntity(state.selectedEntityKind, cell.x, cell.y);
      } else if (state.tool === 'select') {
        state.selectEntityAt(cell.x, cell.y);
        draggingEntityRef.current = state.project.entities.slice().reverse().find((e) => e.x === cell.x && e.y === cell.y)?.id ?? null;
      }
    });

    stage.on('mousemove touchmove', () => {
      const cell = cellAtPointer();
      useStudio.getState().setHover(cell);
      if (!cell) return;
      const state = useStudio.getState();
      if (paintingRef.current && (state.tool === 'brush' || state.tool === 'eraser')) applyBrush(cell);
      if (rectRef.current) {
        rectRef.current = { ...rectRef.current, end: cell };
        setPreview({ ...rectRef.current });
      }
      if (draggingEntityRef.current && state.tool === 'select') state.moveEntity(draggingEntityRef.current, cell.x, cell.y);
    });

    const finish = () => {
      const state = useStudio.getState();
      if (rectRef.current && state.tool === 'rect') {
        const { start, end } = rectRef.current;
        const x0 = Math.min(start.x, end.x), x1 = Math.max(start.x, end.x);
        const y0 = Math.min(start.y, end.y), y1 = Math.max(start.y, end.y);
        const cells: Cell[] = [];
        for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) cells.push({ x, y });
        state.setLevelCells(cells, state.selectedTile);
      }
      rectRef.current = null;
      paintingRef.current = false;
      draggingEntityRef.current = null;
      setPreview(null);
    };
    stage.on('mouseup touchend', finish);
    stage.on('mouseleave', () => {
      useStudio.getState().setHover(null);
      paintingRef.current = false;
      draggingEntityRef.current = null;
    });
    const preventMenu = (event: Event) => event.preventDefault();
    container.addEventListener('contextmenu', preventMenu);
    const windowFinish = () => { if (rectRef.current) finish(); };
    window.addEventListener('mouseup', windowFinish);
    return () => {
      container.removeEventListener('contextmenu', preventMenu);
      window.removeEventListener('mouseup', windowFinish);
      stage.destroy();
      layerRef.current = null;
      imageRef.current = null;
    };
  }, [zoom]);

  useEffect(() => {
    const scene = sceneRef.current;
    const layer = layerRef.current;
    if (!scene || !layer) return;
    scene.width = SCREEN_W * zoom;
    scene.height = SCREEN_H * zoom;
    const ctx = scene.getContext('2d');
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;
    drawLevel(ctx, project, canvases, zoom);

    if (showCollision) {
      for (let y = 0; y < LEVEL_H; y++) {
        for (let x = 0; x < LEVEL_W; x++) {
          const tile = project.tiles[project.level[y * LEVEL_W + x] ?? 0];
          if (tile?.solid) { ctx.fillStyle = 'rgba(0, 255, 80, .22)'; ctx.fillRect(x * 8 * zoom, y * 8 * zoom, 8 * zoom, 8 * zoom); }
          if (tile?.hazard) { ctx.fillStyle = 'rgba(255, 32, 32, .34)'; ctx.fillRect(x * 8 * zoom, y * 8 * zoom, 8 * zoom, 8 * zoom); }
        }
      }
    }

    drawEntities(ctx, project, canvases, project.entities, zoom);

    if (showGrid) {
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(255,255,255,.14)';
      ctx.beginPath();
      for (let x = 0; x <= LEVEL_W; x++) { ctx.moveTo(x * 8 * zoom + 0.5, 0); ctx.lineTo(x * 8 * zoom + 0.5, SCREEN_H * zoom); }
      for (let y = 0; y <= LEVEL_H; y++) { ctx.moveTo(0, y * 8 * zoom + 0.5); ctx.lineTo(SCREEN_W * zoom, y * 8 * zoom + 0.5); }
      ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,0,.19)';
      ctx.beginPath();
      for (let x = 0; x <= LEVEL_W; x += 2) { ctx.moveTo(x * 8 * zoom + 0.5, 0); ctx.lineTo(x * 8 * zoom + 0.5, SCREEN_H * zoom); }
      for (let y = 0; y <= LEVEL_H; y += 2) { ctx.moveTo(0, y * 8 * zoom + 0.5); ctx.lineTo(SCREEN_W * zoom, y * 8 * zoom + 0.5); }
      ctx.stroke();
    }

    if (preview) {
      const x0 = Math.min(preview.start.x, preview.end.x);
      const y0 = Math.min(preview.start.y, preview.end.y);
      const x1 = Math.max(preview.start.x, preview.end.x);
      const y1 = Math.max(preview.start.y, preview.end.y);
      ctx.globalAlpha = 0.54;
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        if (canvases[selectedTile]) ctx.drawImage(canvases[selectedTile], x * 8 * zoom, y * 8 * zoom, 8 * zoom, 8 * zoom);
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = '#F8F8F8';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(x0 * 8 * zoom, y0 * 8 * zoom, (x1 - x0 + 1) * 8 * zoom, (y1 - y0 + 1) * 8 * zoom);
      ctx.setLineDash([]);
    }

    if (hover && (tool === 'brush' || tool === 'eraser' || tool === 'entity')) {
      ctx.globalAlpha = 0.68;
      if (tool === 'entity') {
        const kind = useStudio.getState().selectedEntityKind;
        const sprite = canvases[ENTITY_TILE[kind]];
        if (sprite) ctx.drawImage(sprite, hover.x * 8 * zoom, hover.y * 8 * zoom, 8 * zoom, 8 * zoom);
      } else if (tool !== 'eraser' && canvases[selectedTile]) {
        ctx.drawImage(canvases[selectedTile], hover.x * 8 * zoom, hover.y * 8 * zoom, 8 * zoom, 8 * zoom);
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.strokeRect(hover.x * 8 * zoom + 1, hover.y * 8 * zoom + 1, 8 * zoom - 2, 8 * zoom - 2);
    }

    const selected = project.entities.find((e) => e.id === selectedEntityId);
    if (selected) {
      ctx.strokeStyle = '#FCFC54';
      ctx.lineWidth = 2;
      ctx.setLineDash([3, 2]);
      ctx.strokeRect(selected.x * 8 * zoom - 2, selected.y * 8 * zoom - 2, 8 * zoom + 4, 8 * zoom + 4);
      ctx.setLineDash([]);
    }

    imageRef.current?.image(scene as CanvasImageSource);
    layer.batchDraw();
  }, [project, canvases, zoom, showGrid, showCollision, hover, preview, tool, selectedTile, selectedEntityId]);

  return <div className="level-stage-wrap"><div ref={containerRef} className="level-stage" /></div>;
};

export const LevelWorkspace = ({ project, canvases }: { project: Project; canvases: HTMLCanvasElement[] }) => {
  const nonEmpty = useMemo(() => project.level.filter(Boolean).length, [project.level]);
  const hints = ['32×30 nametable = 960 tiles', '8×8 CHR cells · 4 palettes', 'NTSC 256×240'];
  return (
    <div className="level-workspace">
      <TilePalette project={project} />
      <div className="level-main">
        <div className="canvas-info-bar">
          <span><b>LEVEL 1-1</b> · {project.name}</span>
          <span>{nonEmpty} painted cells · {project.entities.length} objects</span>
          <span>{hints.join('  |  ')}</span>
        </div>
        <LevelCanvas project={project} canvases={canvases} />
      </div>
    </div>
  );
};
