import { useEffect, useRef, useState } from 'react';
import { NES, Controller, type ButtonKey } from 'jsnes';
import { toast } from 'sonner';
import { Gamepad2, RefreshCw, Volume2 } from 'lucide-react';
import { ENTITY_TILE } from '../data/project';
import { playSfx } from '../lib/audio';
import { bodyCollides, drawEntities, drawLevel, hazardAt, mix } from '../lib/render';
import { useStudio } from '../store/useStudio';
import type { Project } from '../types';

interface Player { x: number; y: number; vx: number; vy: number; ground: boolean }
interface GameState {
  player: Player;
  collected: Set<number>;
  defeated: Set<number>;
  score: number;
  lives: number;
  time: number;
  won: boolean;
  frame: number;
  boost: number;
}

export const Html5Preview = ({ project, canvases }: { project: Project; canvases: HTMLCanvasElement[] }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const resetRef = useRef<() => void>(() => {});

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const state: GameState = {
      player: { x: 16, y: 208, vx: 0, vy: 0, ground: false },
      collected: new Set(), defeated: new Set(), score: 0, lives: project.lives,
      time: project.timeLimit, won: false, frame: 0, boost: 0,
    };
    const keys: Record<string, boolean> = {};
    const spawn = project.entities.find((e) => e.kind === 'player') ?? { x: 2, y: 26 };
    const softReset = () => { state.player = { x: spawn.x * 8, y: spawn.y * 8, vx: 0, vy: 0, ground: false }; };
    const fullReset = () => {
      softReset();
      state.collected = new Set(); state.defeated = new Set(); state.score = 0;
      state.lives = project.lives; state.time = project.timeLimit; state.won = false;
      state.frame = 0; state.boost = 0;
    };
    resetRef.current = fullReset;
    fullReset();

    const loseLife = () => {
      state.lives -= 1;
      playSfx('hurt');
      softReset();
      if (state.lives <= 0) fullReset();
    };
    const hit = (box: { x: number; y: number }) =>
      state.player.x < box.x + 8 && state.player.x + 8 > box.x && state.player.y < box.y + 8 && state.player.y + 8 > box.y;

    const onKeyDown = (event: KeyboardEvent) => {
      keys[event.code] = true;
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'Space'].includes(event.code)) event.preventDefault();
      if (event.code === 'KeyR') { fullReset(); playSfx('click'); }
      if (['Space', 'KeyZ', 'KeyW', 'ArrowUp'].includes(event.code) && state.player.ground && !state.won) playSfx('jump');
    };
    const onKeyUp = (event: KeyboardEvent) => { keys[event.code] = false; };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    const update = () => {
      state.frame += 1;
      if (state.won || state.time <= 0) return;
      state.time = Math.max(0, state.time - 1 / 60);
      const p = state.player;
      p.vx = (keys.ArrowRight || keys.KeyD ? project.speed : 0) - (keys.ArrowLeft || keys.KeyA ? project.speed : 0);
      if ((keys.Space || keys.KeyZ || keys.KeyW || keys.ArrowUp) && p.ground) {
        p.vy = -(project.jump + state.boost);
        p.ground = false;
      }
      p.vy = Math.min(5, p.vy + project.gravity);
      const nx = Math.max(0, Math.min(248, p.x + p.vx));
      if (!bodyCollides(project, nx, p.y)) p.x = nx;
      const ny = p.y + p.vy;
      if (!bodyCollides(project, p.x, ny)) { p.y = ny; p.ground = false; }
      else {
        if (p.vy > 0) { p.y = Math.floor(ny / 8) * 8; p.ground = true; }
        p.vy = 0;
      }
      if (hazardAt(project, p.x + 4, p.y + 4) || p.y > 232) loseLife();
      project.entities.forEach((entity, index) => {
        const box = { x: entity.x * 8, y: entity.y * 8 };
        if (entity.kind === 'coin' && !state.collected.has(index) && hit(box)) {
          state.collected.add(index); state.score += 100; playSfx('coin');
        }
        if (entity.kind === 'power' && !state.collected.has(index) && hit(box)) {
          state.collected.add(index); state.score += 250; state.boost = Math.min(1.5, state.boost + 0.35); playSfx('success');
        }
        if (entity.kind === 'enemy' && !state.defeated.has(index) && hit(box)) {
          if (p.vy > 0 && p.y + 8 < box.y + 5) { state.defeated.add(index); p.vy = -3; state.score += 200; playSfx('coin'); }
          else loseLife();
        }
        if (entity.kind === 'goal' && hit(box)) { state.won = true; state.score += 1000; playSfx('win'); }
      });
    };

    const draw = () => {
      ctx.imageSmoothingEnabled = false;
      drawLevel(ctx, project, canvases, 1);
      const visible = project.entities.filter((entity, index) =>
        entity.kind !== 'player' && !state.collected.has(index) && !state.defeated.has(index));
      drawEntities(ctx, project, canvases, visible, 1, state.frame);
      ctx.drawImage(canvases[ENTITY_TILE.player], state.player.x, state.player.y);
      ctx.fillStyle = 'rgba(0,0,0,.55)';
      ctx.fillRect(0, 0, 256, 14);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '8px monospace';
      ctx.fillText(`SCORE ${String(state.score).padStart(6, '0')}`, 4, 10);
      ctx.fillText(`LIVES ${state.lives}`, 104, 10);
      ctx.fillText(`TIME ${Math.ceil(state.time)}`, 170, 10);
      ctx.fillText(project.name.slice(0, 12), 214, 10);
      if (state.won) {
        ctx.fillStyle = 'rgba(0,0,0,.76)'; ctx.fillRect(28, 78, 200, 76);
        ctx.strokeStyle = '#FCFC54'; ctx.lineWidth = 2; ctx.strokeRect(30, 80, 196, 72);
        ctx.fillStyle = '#FCFC54'; ctx.font = 'bold 15px monospace'; ctx.textAlign = 'center';
        ctx.fillText('STAGE CLEAR!', 128, 110);
        ctx.font = '8px monospace'; ctx.fillText(`FINAL SCORE ${state.score}  ·  PRESS R`, 128, 132);
        ctx.textAlign = 'left';
      } else if (state.time <= 0) {
        ctx.fillStyle = 'rgba(0,0,0,.7)'; ctx.fillRect(52, 96, 152, 46);
        ctx.fillStyle = '#FFFFFF'; ctx.font = 'bold 12px monospace'; ctx.textAlign = 'center';
        ctx.fillText('TIME UP', 128, 124); ctx.textAlign = 'left';
      }
      ctx.fillStyle = mix(project.palette[0], -0.45);
      ctx.fillRect(0, 236, 256, 4);
    };

    let raf = 0;
    let last = performance.now();
    let accumulator = 0;
    const tick = (now: number) => {
      accumulator += now - last;
      last = now;
      let steps = 0;
      while (accumulator >= 16.666 && steps < 4) { update(); accumulator -= 16.666; steps += 1; }
      draw();
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [project, canvases]);

  return (
    <div className="runtime-view">
      <div className="runtime-header">
        <div><span className="eyebrow">DUAL TARGET · HTML5 CANVAS</span><h2>PLAYTEST PREVIEW</h2></div>
        <div className="runtime-controls"><Volume2 size={13} /> Tone.js chiptune · 60 FPS AABB physics</div>
        <button className="win-button" onClick={() => { resetRef.current(); playSfx('click'); }}><RefreshCw size={12} /> Restart</button>
      </div>
      <div className="runtime-screen-wrap">
        <canvas ref={canvasRef} width={256} height={240} className="runtime-canvas" />
      </div>
      <div className="runtime-help">← → / A D move &nbsp;·&nbsp; SPACE / Z / W / ↑ jump &nbsp;·&nbsp; R restart &nbsp;·&nbsp; Stomp enemies, collect coins, reach the flag.</div>
    </div>
  );
};

export const NesEmulator = ({ rom, project }: { rom: Uint8Array; project: Project }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nesRef = useRef<NES | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [booted, setBooted] = useState(false);
  const needsBuild = useStudio((s) => s.needsBuild);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    setBooted(false);
    setError(null);
    const imageData = ctx.createImageData(256, 240);
    const frame32 = new Uint32Array(imageData.data.buffer);
    let firstFrame = true;
    let nes: NES;
    try {
      nes = new NES({
        emulateSound: false,
        onFrame: (frameBuffer: Uint32Array) => {
          for (let i = 0; i < 256 * 240; i++) frame32[i] = 0xff000000 | frameBuffer[i];
          ctx.putImageData(imageData, 0, 0);
          if (firstFrame) { firstFrame = false; setBooted(true); }
        },
      });
      nes.loadROM(rom);
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : 'ROM failed to boot');
      return;
    }
    nesRef.current = nes;
    const buttons: ButtonKey[] = [
      Controller.BUTTON_A, Controller.BUTTON_B, Controller.BUTTON_SELECT, Controller.BUTTON_START,
      Controller.BUTTON_UP, Controller.BUTTON_DOWN, Controller.BUTTON_LEFT, Controller.BUTTON_RIGHT,
    ];
    const keyMap: Record<string, ButtonKey> = {
      ArrowLeft: Controller.BUTTON_LEFT,
      ArrowRight: Controller.BUTTON_RIGHT,
      ArrowUp: Controller.BUTTON_UP,
      ArrowDown: Controller.BUTTON_DOWN,
      KeyA: Controller.BUTTON_LEFT,
      KeyD: Controller.BUTTON_RIGHT,
      KeyW: Controller.BUTTON_UP,
      KeyS: Controller.BUTTON_DOWN,
      KeyZ: Controller.BUTTON_A,
      KeyX: Controller.BUTTON_B,
      Space: Controller.BUTTON_A,
      Enter: Controller.BUTTON_START,
      ShiftRight: Controller.BUTTON_SELECT,
    };
    const onKeyDown = (event: KeyboardEvent) => {
      const button = keyMap[event.code];
      if (button === undefined) return;
      event.preventDefault();
      nes.buttonDown(1, button);
      if (event.code === 'KeyZ' || event.code === 'Space' || event.code === 'KeyW' || event.code === 'ArrowUp') playSfx('jump');
    };
    const onKeyUp = (event: KeyboardEvent) => {
      const button = keyMap[event.code];
      if (button !== undefined) nes.buttonUp(1, button);
    };
    const releaseAll = () => buttons.forEach((button) => nes.buttonUp(1, button));
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', releaseAll);
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      if (now - last >= 16.4) {
        try { nes.frame(); } catch (exception) { setError(exception instanceof Error ? exception.message : 'Emulation halted'); return; }
        last = now;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', releaseAll);
      nesRef.current = null;
    };
  }, [rom]);

  return (
    <div className="runtime-view emulator-view">
      <div className="runtime-header">
        <div><span className="eyebrow">HARDWARE TARGET · JSNES 3.0</span><h2>NROM-256 EMULATION</h2></div>
        <div className="runtime-controls"><Gamepad2 size={13} /> D-Pad / arrows · Z=A · X=B · Enter=Start</div>
        <button className="win-button" onClick={() => { try { nesRef.current?.reloadROM(); toast.success('Cartridge reset'); playSfx('click'); } catch { toast.error('Unable to reset cartridge'); } }}><RefreshCw size={12} /> Reset</button>
      </div>
      <div className="runtime-screen-wrap">
        <div className="crt-frame">
          <canvas ref={canvasRef} width={256} height={240} className="runtime-canvas emulator-canvas" />
          {!booted && !error && <div className="boot-overlay">BOOTING {project.name.toUpperCase()}…</div>}
          {error && <div className="boot-overlay error">EMULATOR ERROR: {error}</div>}
          <div className="crt-scanlines" />
        </div>
      </div>
      <div className="runtime-help">
        {needsBuild ? '⚠ Project has changed since the displayed ROM was assembled. Press BUILD CARTRIDGE to update this emulation.' : '✓ This is the exact .nes binary exported to disk, executing 6502 opcodes through a PPU/APU emulator.'}
      </div>
    </div>
  );
};
