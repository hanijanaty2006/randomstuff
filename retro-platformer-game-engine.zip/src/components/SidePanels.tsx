import { useEffect, useRef, type ReactNode } from 'react';
import clsx from 'clsx';
import { motion } from 'framer-motion';
import {
  AlertTriangle, Box, CheckCircle2, ChevronRight, Circle, Cpu, FileText, Folder,
  Globe, Hammer, Info, Layers, Package, Palette, Settings, Terminal, Trash2, Users, XCircle,
} from 'lucide-react';
import { ENTITY_LABEL, ENTITY_TILE } from '../data/project';
import { nearestNesColor } from '../lib/nesPalette';
import type { BuildResult } from '../lib/nes';
import { useStudio } from '../store/useStudio';
import type { EntityKind, Project, TabId } from '../types';
import { TileSwatch } from './LevelEditor';

export const ProjectExplorer = () => {
  const project = useStudio((s) => s.project);
  const activeTab = useStudio((s) => s.activeTab);
  const setTab = useStudio((s) => s.setTab);
  const node = (label: string, icon: ReactNode, tab: TabId, indent = 0, badge?: string) => (
    <button className={clsx('tree-node', activeTab === tab && 'selected')} style={{ paddingLeft: 8 + indent * 14 }} onClick={() => setTab(tab)}>
      <ChevronRight size={11} className={indent ? 'tree-chevron dim' : 'tree-chevron'} /> {icon} <span>{label}</span>
      {badge && <small>{badge}</small>}
    </button>
  );
  return (
    <aside className="explorer">
      <div className="panel-heading"><Folder size={13} /> PROJECT EXPLORER</div>
      <div className="tree-scroll">
        <div className="tree-root"><Folder size={13} /> {project.name}</div>
        {node('Levels', <Layers size={13} />, 'level', 1)}
        {node('Level 1-1.nam', <FileText size={13} />, 'level', 2, '960')}
        {node('Assets', <Box size={13} />, 'sprites', 1)}
        {node('chr0.bin — 16 tiles', <Palette size={13} />, 'sprites', 2)}
        {node('palettes.pal — 4 banks', <Palette size={13} />, 'sprites', 2)}
        {node('objects.dat', <Users size={13} />, 'level', 2, String(project.entities.length))}
        {node('Targets', <Package size={13} />, 'rom', 1)}
        {node('cartridge.nes — NROM', <Cpu size={13} />, 'rom', 2)}
        {node('index.html — Canvas', <Globe size={13} />, 'preview', 2)}
        {node('Build', <Hammer size={13} />, 'source', 1)}
        {node('engine.asm', <FileText size={13} />, 'source', 2)}
        {node('build.log', <Terminal size={13} />, 'source', 2)}
        {node('jsnes hardware test', <Cpu size={13} />, 'emulator', 2)}
      </div>
      <div className="explorer-footer">
        <div><span>TARGET</span><b>{project.target}</b></div>
        <div><span>VERSION</span><b>v{project.version}</b></div>
        <div><span>MAPPER</span><b>0 / NROM-256</b></div>
      </div>
    </aside>
  );
};

export const PropertiesPanel = ({ project, build }: { project: Project; build: BuildResult }) => {
  const selectedTileId = useStudio((s) => s.selectedTile);
  const selectedEntityId = useStudio((s) => s.selectedEntityId);
  const setTileMeta = useStudio((s) => s.setTileMeta);
  const moveEntity = useStudio((s) => s.moveEntity);
  const deleteEntity = useStudio((s) => s.deleteEntity);
  const updateProject = useStudio((s) => s.updateProject);
  const setDialog = useStudio((s) => s.setDialog);
  const tile = project.tiles[selectedTileId];
  const entity = project.entities.find((e) => e.id === selectedEntityId);
  const base = (tile?.palette ?? 0) * 4;
  const hardware = nearestNesColor(project.palette[base + 1] ?? '#000000');

  const patchEntity = (patch: Partial<{ kind: EntityKind; x: number; y: number }>) => {
    if (!entity) return;
    updateProject({ entities: project.entities.map((e) => (e.id === entity.id ? { ...e, ...patch } : e)) });
  };

  return (
    <aside className="properties-panel">
      <div className="panel-heading"><Settings size={13} /> PROPERTIES</div>
      <div className="properties-scroll">
        <section className="property-section">
          <h4><Box size={12} /> TILE INSPECTOR</h4>
          <div className="tile-inspector-head">
            <TileSwatch tile={tile} palette={project.palette} size={48} />
            <div><b>{tile?.name}</b><small>CHR index ${selectedTileId.toString(16).toUpperCase().padStart(2, '0')} · bank {tile?.palette}</small></div>
          </div>
          <label className="field-label">Name</label>
          <input className="win-input" value={tile?.name ?? ''} onChange={(e) => setTileMeta(selectedTileId, { name: e.target.value })} />
          <div className="compact-grid">
            <label className="checkbox-row"><input type="checkbox" checked={Boolean(tile?.solid)} onChange={(e) => setTileMeta(selectedTileId, { solid: e.target.checked })} /> Solid</label>
            <label className="checkbox-row"><input type="checkbox" checked={Boolean(tile?.hazard)} onChange={(e) => setTileMeta(selectedTileId, { hazard: e.target.checked })} /> Hazard</label>
          </div>
          <label className="field-label">PPU palette</label>
          <select className="win-select" value={tile?.palette ?? 0} onChange={(e) => setTileMeta(selectedTileId, { palette: Number(e.target.value) })}>
            {[0, 1, 2, 3].map((i) => <option key={i} value={i}>Palette {i} · $3F{i.toString(16).toUpperCase()}0</option>)}
          </select>
          <div className="hardware-note"><Cpu size={12} /> Nearest 2C02 color: <b>${hardware.index.toString(16).toUpperCase().padStart(2, '0')}</b> {hardware.hex}</div>
        </section>

        <section className="property-section">
          <h4><Users size={12} /> OBJECT INSPECTOR</h4>
          {entity ? (
            <>
              <div className="entity-summary">
                <TileSwatch tile={project.tiles[ENTITY_TILE[entity.kind]]} palette={project.palette} size={28} />
                <span>{ENTITY_LABEL[entity.kind]}</span>
                <button className="tiny-button danger" onClick={() => deleteEntity(entity.id)} title="Delete object"><Trash2 size={11} /></button>
              </div>
              <label className="field-label">Kind</label>
              <select className="win-select" value={entity.kind} onChange={(e) => patchEntity({ kind: e.target.value as EntityKind })}>
                {Object.entries(ENTITY_LABEL).map(([kind, label]) => <option key={kind} value={kind}>{label}</option>)}
              </select>
              <div className="compact-grid two">
                <div><label className="field-label">Tile X</label><input className="win-input" type="number" min={0} max={31} value={entity.x} onChange={(e) => moveEntity(entity.id, Number(e.target.value), entity.y)} /></div>
                <div><label className="field-label">Tile Y</label><input className="win-input" type="number" min={0} max={29} value={entity.y} onChange={(e) => moveEntity(entity.id, entity.x, Number(e.target.value))} /></div>
              </div>
            </>
          ) : (
            <div className="empty-note"><Info size={13} /> Select an object with the SELECT tool or place a new one.</div>
          )}
        </section>

        <section className="property-section">
          <h4><Cpu size={12} /> PROJECT / RUNTIME</h4>
          <div className="stat-rows">
            <div><span>Gravity</span><b>{project.gravity.toFixed(2)}</b></div>
            <div><span>Run speed</span><b>{project.speed.toFixed(2)} px/f</b></div>
            <div><span>Jump impulse</span><b>-{project.jump.toFixed(2)}</b></div>
            <div><span>Lives / Timer</span><b>{project.lives} / {project.timeLimit}s</b></div>
            <div><span>Entities / OAM</span><b>{project.entities.length} / 64</b></div>
          </div>
          <button className="win-button wide" onClick={() => setDialog('settings')}><Settings size={12} /> Edit Game Settings</button>
        </section>

        <section className="property-section">
          <h4><CheckCircle2 size={12} /> BUILD VALIDATION</h4>
          {build.warnings.length ? build.warnings.map((warning) => (
            <div className="validation-warning" key={warning}><AlertTriangle size={12} /> {warning}</div>
          )) : (
            <div className="validation-ok"><CheckCircle2 size={13} /> No hardware validation errors.</div>
          )}
          <div className="checksum-box">ROM CHECKSUM <b>{build.checksum}</b></div>
        </section>
      </div>
    </aside>
  );
};

export const BuildConsole = ({ build }: { build: BuildResult }) => {
  const logs = useStudio((s) => s.logs);
  const clearLogs = useStudio((s) => s.clearLogs);
  const toggleConsole = useStudio((s) => s.toggleConsole);
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [logs]);
  const icon = (level: string) => {
    if (level === 'ok') return <CheckCircle2 size={12} />;
    if (level === 'warn') return <AlertTriangle size={12} />;
    if (level === 'error') return <XCircle size={12} />;
    return <Circle size={9} />;
  };
  return (
    <div className="build-console">
      <div className="console-header">
        <span><Terminal size={13} /> BUILD OUTPUT · 6502 ASSEMBLER / NROM LINKER</span>
        <span className="console-meta">PRG 32K · CHR 8K · {build.assemblyResult.lineCount} statements · {build.checksum}</span>
        <button onClick={clearLogs} title="Clear console">CLR</button>
        <button onClick={toggleConsole} title="Collapse console">_</button>
      </div>
      <div className="console-scroll" ref={scrollRef}>
        {logs.map((log) => (
          <motion.div key={log.id} className={clsx('console-line', log.level)} initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.12 }}>
            <span className="console-time">[{log.time}]</span>{icon(log.level)}<span>{log.message}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
