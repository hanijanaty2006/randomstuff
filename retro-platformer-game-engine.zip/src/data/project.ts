import { nanoid } from 'nanoid';
import { LEVEL_H, LEVEL_W, type Entity, type EntityKind, type Project, type TileDef } from '../types';

const p = (rows: string[]): number[] =>
  rows.flatMap((row) => [...row].map((ch) => (ch === '.' ? 0 : Number(ch))));

export const ENTITY_TILE: Record<EntityKind, number> = {
  player: 11,
  enemy: 12,
  coin: 13,
  power: 14,
  goal: 15,
};

export const ENTITY_LABEL: Record<EntityKind, string> = {
  player: 'Player Spawn',
  enemy: 'Walker Enemy',
  coin: 'Coin',
  power: 'Power Up',
  goal: 'Level Goal',
};

export const defaultTiles = (): TileDef[] => [
  { id: 0, name: 'Empty / Sky', group: 'decor', solid: false, hazard: false, palette: 0, pattern: p(['........','........','........','........','........','........','........','........']) },
  { id: 1, name: 'Ground Block', group: 'terrain', solid: true, hazard: false, palette: 0, pattern: p(['11111111','12222221','12333231','12222221','13311331','12222221','12333231','11111111']) },
  { id: 2, name: 'Brick Block', group: 'terrain', solid: true, hazard: false, palette: 0, pattern: p(['11111111','13311331','13311331','11111111','13311331','13311331','11111111','11111111']) },
  { id: 3, name: 'Question Block', group: 'terrain', solid: true, hazard: false, palette: 3, pattern: p(['11111111','12222221','12333221','12233221','12222221','12233221','12233221','11111111']) },
  { id: 4, name: 'One-way Platform', group: 'terrain', solid: true, hazard: false, palette: 1, pattern: p(['33333333','22222222','11111111','11111111','11111111','11111111','11111111','11111111']) },
  { id: 5, name: 'Spike Strip', group: 'terrain', solid: false, hazard: true, palette: 1, pattern: p(['1.......','11......','121.....','1221....','12321...','122321..','1232321.','11111111']) },
  { id: 6, name: 'Cloud', group: 'decor', solid: false, hazard: false, palette: 1, pattern: p(['........','..222...','.23332..','23333332','23333332','.23332..','..222...','........']) },
  { id: 7, name: 'Pipe Segment', group: 'terrain', solid: true, hazard: false, palette: 3, pattern: p(['.111111.','.233332.','.231132.','.231132.','.231132.','.231132.','.233332.','.111111.']) },
  { id: 8, name: 'Stone Block', group: 'terrain', solid: true, hazard: false, palette: 1, pattern: p(['11111111','12222221','12333321','12222221','12222121','12333221','12222221','11111111']) },
  { id: 9, name: 'Lava / Water', group: 'terrain', solid: false, hazard: true, palette: 2, pattern: p(['........','........','22222222','33333333','22222222','33333333','22222222','11111111']) },
  { id: 10, name: 'Castle Wall', group: 'decor', solid: false, hazard: false, palette: 0, pattern: p(['..1..1..','11111111','12233221','12233221','12222221','12333321','12211221','11111111']) },
  { id: 11, name: 'Hero Sprite', group: 'actor', solid: false, hazard: false, palette: 2, pattern: p(['..2222..','.233332.','.231132.','.222222.','..1111..','.111111.','.11..11.','11....11']) },
  { id: 12, name: 'Walker Sprite', group: 'actor', solid: false, hazard: false, palette: 2, pattern: p(['..1111..','.122221.','12333321','12111121','12333321','12222221','1.1111.1','1......1']) },
  { id: 13, name: 'Coin Sprite', group: 'pickup', solid: false, hazard: false, palette: 0, pattern: p(['..3333..','.322223.','32.33.23','32.33.23','32.33.23','32.33.23','.322223.','..3333..']) },
  { id: 14, name: 'Power Capsule', group: 'pickup', solid: false, hazard: false, palette: 3, pattern: p(['..1111..','.122221.','12333321','12222221','12333321','12222221','.111111.','..1111..']) },
  { id: 15, name: 'Goal Flag', group: 'pickup', solid: false, hazard: false, palette: 3, pattern: p(['.333333.','.322222.','.32.....','.32.....','.322222.','.32.....','.32.....','11111111']) },
];

const entity = (kind: EntityKind, x: number, y: number): Entity => ({ id: nanoid(8), kind, x, y });

export const createDefaultLevel = (): number[] => {
  const level = new Array<number>(LEVEL_W * LEVEL_H).fill(0);
  const set = (x: number, y: number, id: number) => {
    if (x >= 0 && x < LEVEL_W && y >= 0 && y < LEVEL_H) level[y * LEVEL_W + x] = id;
  };
  const box = (x0: number, y0: number, x1: number, y1: number, id: number) => {
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) set(x, y, id);
  };

  box(0, 27, 31, 29, 1);
  box(16, 27, 18, 29, 0);
  box(16, 29, 18, 29, 9);
  box(4, 22, 7, 22, 2);
  set(6, 22, 3);
  box(10, 19, 13, 19, 4);
  box(16, 24, 18, 24, 2);
  box(22, 21, 25, 21, 8);
  set(23, 21, 3);
  box(27, 17, 30, 17, 4);
  box(8, 24, 9, 26, 7);
  box(24, 24, 25, 26, 7);
  set(14, 26, 5);
  set(21, 26, 5);
  for (const [x, y] of [[3, 4], [12, 3], [20, 6], [27, 4], [7, 9]]) set(x, y, 6);
  box(29, 25, 29, 26, 10);
  box(0, 0, 31, 0, 0);
  return level;
};

export const createDefaultProject = (): Project => ({
  name: 'PIXEL QUEST 98',
  author: 'NES MAKER STUDIO',
  version: '1.0.0',
  description: 'A dual-target 2D platformer built for NROM-256 hardware and HTML5 canvas.',
  target: 'Dual target',
  gravity: 0.34,
  speed: 1.45,
  jump: 4.7,
  lives: 3,
  timeLimit: 300,
  palette: [
    '#5C94FC', '#2038EC', '#D82800', '#FCFC54',
    '#5C94FC', '#7C7C7C', '#BCBCBC', '#F8F8F8',
    '#5C94FC', '#503000', '#F83800', '#F8B800',
    '#5C94FC', '#007800', '#00A800', '#F8F8F8',
  ],
  tiles: defaultTiles(),
  level: createDefaultLevel(),
  entities: [
    entity('player', 2, 26),
    entity('enemy', 10, 26),
    entity('enemy', 22, 26),
    entity('enemy', 24, 20),
    entity('coin', 5, 21),
    entity('coin', 11, 18),
    entity('coin', 17, 23),
    entity('coin', 23, 20),
    entity('coin', 28, 16),
    entity('power', 12, 18),
    entity('goal', 30, 26),
  ],
  updatedAt: Date.now(),
});

export const blankProject = (): Project => {
  const project = createDefaultProject();
  project.name = 'UNTITLED CARTRIDGE';
  project.level = new Array<number>(LEVEL_W * LEVEL_H).fill(0);
  for (let x = 0; x < LEVEL_W; x++) {
    project.level[27 * LEVEL_W + x] = 1;
    project.level[28 * LEVEL_W + x] = 1;
    project.level[29 * LEVEL_W + x] = 1;
  }
  project.entities = [entity('player', 2, 26), entity('goal', 29, 26)];
  project.updatedAt = Date.now();
  return project;
};
