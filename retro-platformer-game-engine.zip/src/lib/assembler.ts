type Mode = 'imp' | 'acc' | 'imm' | 'zp' | 'zpx' | 'zpy' | 'abs' | 'abx' | 'aby' | 'ind' | 'inx' | 'iny' | 'rel';

type OpcodeSet = Partial<Record<Mode, number>>;

const OPCODES: Record<string, OpcodeSet> = {
  ADC: { imm: 0x69, zp: 0x65, zpx: 0x75, abs: 0x6d, abx: 0x7d, aby: 0x79, inx: 0x61, iny: 0x71 },
  AND: { imm: 0x29, zp: 0x25, zpx: 0x35, abs: 0x2d, abx: 0x3d, aby: 0x39, inx: 0x21, iny: 0x31 },
  ASL: { acc: 0x0a, zp: 0x06, zpx: 0x16, abs: 0x0e, abx: 0x1e },
  BCC: { rel: 0x90 }, BCS: { rel: 0xb0 }, BEQ: { rel: 0xf0 }, BMI: { rel: 0x30 }, BNE: { rel: 0xd0 }, BPL: { rel: 0x10 }, BVC: { rel: 0x50 }, BVS: { rel: 0x70 },
  BIT: { zp: 0x24, abs: 0x2c },
  CLC: { imp: 0x18 }, CLD: { imp: 0xd8 }, CLI: { imp: 0x58 }, SEC: { imp: 0x38 }, SEI: { imp: 0x78 },
  CMP: { imm: 0xc9, zp: 0xc5, zpx: 0xd5, abs: 0xcd, abx: 0xdd, aby: 0xd9, inx: 0xc1, iny: 0xd1 },
  CPX: { imm: 0xe0, zp: 0xe4, abs: 0xec }, CPY: { imm: 0xc0, zp: 0xc4, abs: 0xcc },
  DEC: { zp: 0xc6, zpx: 0xd6, abs: 0xce, abx: 0xde }, DEX: { imp: 0xca }, DEY: { imp: 0x88 },
  EOR: { imm: 0x49, zp: 0x45, zpx: 0x55, abs: 0x4d, abx: 0x5d, aby: 0x59, inx: 0x41, iny: 0x51 },
  INC: { zp: 0xe6, zpx: 0xf6, abs: 0xee, abx: 0xfe }, INX: { imp: 0xe8 }, INY: { imp: 0xc8 },
  JMP: { abs: 0x4c, ind: 0x6c }, JSR: { abs: 0x20 },
  LDA: { imm: 0xa9, zp: 0xa5, zpx: 0xb5, abs: 0xad, abx: 0xbd, aby: 0xb9, inx: 0xa1, iny: 0xb1 },
  LDX: { imm: 0xa2, zp: 0xa6, zpy: 0xb6, abs: 0xae, aby: 0xbe },
  LDY: { imm: 0xa0, zp: 0xa4, zpx: 0xb4, abs: 0xac, abx: 0xbc },
  LSR: { acc: 0x4a, zp: 0x46, zpx: 0x56, abs: 0x4e, abx: 0x5e },
  NOP: { imp: 0xea },
  ORA: { imm: 0x09, zp: 0x05, zpx: 0x15, abs: 0x0d, abx: 0x1d, aby: 0x19, inx: 0x01, iny: 0x11 },
  PHA: { imp: 0x48 }, PHP: { imp: 0x08 }, PLA: { imp: 0x68 }, PLP: { imp: 0x28 },
  ROL: { acc: 0x2a, zp: 0x26, zpx: 0x36, abs: 0x2e, abx: 0x3e },
  ROR: { acc: 0x6a, zp: 0x66, zpx: 0x76, abs: 0x6e, abx: 0x7e },
  RTI: { imp: 0x40 }, RTS: { imp: 0x60 },
  SBC: { imm: 0xe9, zp: 0xe5, zpx: 0xf5, abs: 0xed, abx: 0xfd, aby: 0xf9, inx: 0xe1, iny: 0xf1 },
  STA: { zp: 0x85, zpx: 0x95, abs: 0x8d, abx: 0x9d, aby: 0x99, inx: 0x81, iny: 0x91 },
  STX: { zp: 0x86, zpy: 0x96, abs: 0x8e }, STY: { zp: 0x84, zpx: 0x94, abs: 0x8c },
  TAX: { imp: 0xaa }, TAY: { imp: 0xa8 }, TSX: { imp: 0xba }, TXA: { imp: 0x8a }, TXS: { imp: 0x9a }, TYA: { imp: 0x98 },
};

interface ParsedLine {
  line: number;
  address: number;
  mnemonic: string;
  operand: string;
  mode: Mode;
  size: number;
  values?: string[];
}

const isBranch = (m: string) => ['BCC', 'BCS', 'BEQ', 'BMI', 'BNE', 'BPL', 'BVC', 'BVS'].includes(m);

const stripComment = (line: string) => {
  const index = line.indexOf(';');
  return (index >= 0 ? line.slice(0, index) : line).trim();
};

const parseNumber = (token: string): number | null => {
  const value = token.trim();
  if (/^\$[0-9a-f]+$/i.test(value)) return Number.parseInt(value.slice(1), 16);
  if (/^%[01]+$/.test(value)) return Number.parseInt(value.slice(1), 2);
  if (/^0x[0-9a-f]+$/i.test(value)) return Number.parseInt(value.slice(2), 16);
  if (/^\d+$/.test(value)) return Number.parseInt(value, 10);
  return null;
};

const splitValues = (text: string) => text.split(',').map((v) => v.trim()).filter(Boolean);

const classify = (mnemonic: string, operand: string, symbols: Record<string, number>): { mode: Mode; size: number; base: string } => {
  if (isBranch(mnemonic)) return { mode: 'rel', size: 2, base: operand };
  if (!operand) return { mode: 'imp', size: 1, base: '' };
  if (operand.toUpperCase() === 'A') return { mode: 'acc', size: 1, base: '' };
  if (operand.startsWith('#')) return { mode: 'imm', size: 2, base: operand.slice(1) };
  if (/^\(.+,X\)$/i.test(operand)) return { mode: 'inx', size: 2, base: operand.slice(1, -3).trim() };
  if (/^\(.+\),Y$/i.test(operand)) return { mode: 'iny', size: 2, base: operand.slice(1, operand.indexOf('),Y')).trim() };
  if (/^\(.+\)$/.test(operand)) return { mode: 'ind', size: 3, base: operand.slice(1, -1).trim() };

  const upper = operand.toUpperCase();
  const suffix = upper.endsWith(',X') ? 'x' : upper.endsWith(',Y') ? 'y' : '';
  const base = suffix ? operand.slice(0, -2).trim() : operand.trim();
  const numeric = parseNumber(base) ?? symbols[base] ?? symbols[base.toLowerCase()];
  const zeroPage = numeric !== null && numeric !== undefined && numeric >= 0 && numeric <= 0xff;
  if (mnemonic === 'JMP' || mnemonic === 'JSR') return { mode: mnemonic === 'JMP' && !suffix ? 'abs' : 'abs', size: 3, base };
  let mode: Mode;
  if (suffix === 'x') mode = zeroPage ? 'zpx' : 'abx';
  else if (suffix === 'y') mode = zeroPage ? 'zpy' : 'aby';
  else mode = zeroPage ? 'zp' : 'abs';
  return { mode, size: mode.startsWith('zp') ? 2 : 3, base };
};

const evaluate = (raw: string, symbols: Record<string, number>): number => {
  let expr = raw.trim();
  let lowByte = false;
  let highByte = false;
  if (expr.startsWith('<')) { lowByte = true; expr = expr.slice(1); }
  else if (expr.startsWith('>')) { highByte = true; expr = expr.slice(1); }
  const parts = expr.split(/([+-])/).map((v) => v.trim()).filter(Boolean);
  let total = 0;
  let op = 1;
  for (const part of parts) {
    if (part === '+') { op = 1; continue; }
    if (part === '-') { op = -1; continue; }
    const numeric = parseNumber(part);
    let value: number;
    if (numeric !== null) value = numeric;
    else if (part in symbols) value = symbols[part];
    else if (part.toLowerCase() in symbols) value = symbols[part.toLowerCase()];
    else throw new Error(`Unknown symbol "${part}"`);
    total += op * value;
    op = 1;
  }
  if (lowByte) return total & 0xff;
  if (highByte) return (total >> 8) & 0xff;
  return total & 0xffff;
};

export interface AssemblyResult {
  prg: Uint8Array;
  symbols: Record<string, number>;
  usedBytes: number;
  lineCount: number;
}

export const assemble6502 = (source: string): AssemblyResult => {
  const symbols: Record<string, number> = {};
  const lines: ParsedLine[] = [];
  let pc = 0x8000;
  let maxAddress = pc;

  source.split('\n').forEach((raw, lineIndex) => {
    let text = stripComment(raw);
    if (!text) return;
    // Symbol assignment: name = expression
    const assignment = text.match(/^([A-Za-z_][\w]*)\s*=\s*(.+)$/);
    if (assignment) {
      symbols[assignment[1]] = evaluate(assignment[2], symbols);
      return;
    }
    while (/^([A-Za-z_][\w]*):/.test(text)) {
      const label = text.match(/^([A-Za-z_][\w]*):/)![1];
      symbols[label] = pc;
      text = text.slice(label.length + 1).trim();
    }
    if (!text) return;

    if (/^\.org\b/i.test(text)) {
      pc = evaluate(text.replace(/^\.org\s*/i, ''), symbols);
      maxAddress = Math.max(maxAddress, pc);
      return;
    }
    if (/^\.byte\b|^db\b/i.test(text)) {
      const values = splitValues(text.replace(/^\.byte\s*|^db\s*/i, ''));
      lines.push({ line: lineIndex + 1, address: pc, mnemonic: '.byte', operand: '', mode: 'imp', size: values.length, values });
      pc += values.length;
      maxAddress = Math.max(maxAddress, pc);
      return;
    }
    if (/^\.word\b|^dw\b/i.test(text)) {
      const values = splitValues(text.replace(/^\.word\s*|^dw\s*/i, ''));
      lines.push({ line: lineIndex + 1, address: pc, mnemonic: '.word', operand: '', mode: 'imp', size: values.length * 2, values });
      pc += values.length * 2;
      maxAddress = Math.max(maxAddress, pc);
      return;
    }
    if (/^\.res\b/i.test(text)) {
      const count = evaluate(text.replace(/^\.res\s*/i, ''), symbols);
      pc += count;
      maxAddress = Math.max(maxAddress, pc);
      return;
    }
    if (/^\.align\b/i.test(text)) {
      const boundary = evaluate(text.replace(/^\.align\s*/i, ''), symbols);
      pc = Math.ceil(pc / boundary) * boundary;
      maxAddress = Math.max(maxAddress, pc);
      return;
    }

    const match = text.match(/^([A-Za-z]{2,4})\s*(.*)$/);
    if (!match) throw new Error(`Line ${lineIndex + 1}: cannot parse "${text}"`);
    const mnemonic = match[1].toUpperCase();
    const operand = match[2].trim();
    if (!OPCODES[mnemonic]) throw new Error(`Line ${lineIndex + 1}: unknown mnemonic ${mnemonic}`);
    const { mode, size, base } = classify(mnemonic, operand, symbols);
    if (!OPCODES[mnemonic][mode]) throw new Error(`Line ${lineIndex + 1}: ${mnemonic} does not support ${mode}`);
    lines.push({ line: lineIndex + 1, address: pc, mnemonic, operand: base || operand, mode, size, values: base ? [base] : [] });
    pc += size;
    maxAddress = Math.max(maxAddress, pc);
  });

  const prg = new Uint8Array(0x8000).fill(0xff);
  const write = (address: number, value: number) => {
    if (address < 0x8000 || address > 0xffff) throw new Error(`Address ${address.toString(16)} outside PRG-ROM`);
    prg[address - 0x8000] = value & 0xff;
  };

  for (const item of lines) {
    const address = item.address;
    if (item.mnemonic === '.byte') {
      item.values!.forEach((value, i) => write(address + i, evaluate(value, symbols)));
      continue;
    }
    if (item.mnemonic === '.word') {
      item.values!.forEach((value, i) => {
        const word = evaluate(value, symbols);
        write(address + i * 2, word & 0xff);
        write(address + i * 2 + 1, word >> 8);
      });
      continue;
    }
    const opcode = OPCODES[item.mnemonic][item.mode]!;
    write(address, opcode);
    if (item.mode === 'imp' || item.mode === 'acc') continue;
    if (item.mode === 'rel') {
      const target = evaluate(item.values![0], symbols);
      const offset = target - (address + 2);
      if (offset < -128 || offset > 127) throw new Error(`Line ${item.line}: branch out of range (${offset})`);
      write(address + 1, offset & 0xff);
      continue;
    }
    const value = evaluate(item.values![0], symbols);
    const oneByte = ['imm', 'zp', 'zpx', 'zpy', 'inx', 'iny'].includes(item.mode);
    write(address + 1, value & 0xff);
    if (!oneByte) write(address + 2, (value >> 8) & 0xff);
  }

  return { prg, symbols, usedBytes: maxAddress - 0x8000, lineCount: lines.length };
};
