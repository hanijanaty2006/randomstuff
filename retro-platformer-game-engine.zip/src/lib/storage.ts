import Dexie, { type Table } from 'dexie';
import type { Project, SaveSlot } from '../types';

class StudioDatabase extends Dexie {
  projects!: Table<SaveSlot, string>;

  constructor() {
    super('NesMakerStudio98');
    this.version(1).stores({ projects: 'id, name, updatedAt' });
  }
}

export const db = new StudioDatabase();

export const saveToLibrary = async (id: string, project: Project) => {
  const slot: SaveSlot = {
    id,
    name: project.name,
    updatedAt: Date.now(),
    data: JSON.parse(JSON.stringify(project)) as Project,
  };
  await db.projects.put(slot);
  return slot;
};

export const listLibrary = async () => (await db.projects.orderBy('updatedAt').reverse().toArray());

export const deleteFromLibrary = async (id: string) => db.projects.delete(id);

export const getFromLibrary = async (id: string) => db.projects.get(id);
