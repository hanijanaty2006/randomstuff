import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { generateStandaloneHTML } from './html5';
import type { BuildResult } from './nes';
import type { Project } from '../types';

const slug = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'pixel-quest';

const asBlobPart = (bytes: Uint8Array): BlobPart => bytes as unknown as BlobPart;

export const downloadBytes = (bytes: Uint8Array, filename: string, type = 'application/octet-stream') => {
  saveAs(new Blob([asBlobPart(bytes)], { type }), filename);
};

export const downloadText = (text: string, filename: string, type = 'text/plain;charset=utf-8') => {
  saveAs(new Blob([text], { type }), filename);
};

export const exportROM = (project: Project, build: BuildResult) => {
  downloadBytes(build.rom, `${slug(project.name)}.nes`, 'application/octet-stream');
};

export const exportHTML5 = (project: Project) => {
  downloadText(generateStandaloneHTML(project), `${slug(project.name)}.html`, 'text/html;charset=utf-8');
};

export const exportProjectJSON = (project: Project) => {
  downloadText(JSON.stringify(project, null, 2), `${slug(project.name)}.project.json`, 'application/json;charset=utf-8');
};

export const exportDevKit = async (project: Project, build: BuildResult) => {
  const zip = new JSZip();
  const base = slug(project.name);
  zip.file(`${base}.nes`, build.rom);
  zip.file(`${base}.html`, generateStandaloneHTML(project));
  zip.file('project.json', JSON.stringify(project, null, 2));
  const source = zip.folder('source')!;
  source.file('engine.asm', build.assembly);
  source.file('chr.bin', build.chr);
  source.file('nametable.nam', new Uint8Array(build.nametable));
  source.file('palette.pal', new Uint8Array(build.palette));
  source.file('header.txt', `iNES header\nPRG-ROM: 2 x 16 KiB\nCHR-ROM: 1 x 8 KiB\nMapper: 0 (NROM-256)\nMirroring: horizontal\nChecksum: ${build.checksum}\n`);
  source.file('README.txt', [
    `${project.name} — NES MAKER STUDIO 98 DEVELOPMENT KIT`,
    '',
    'Target hardware: NES / Famicom, NROM-256 (mapper 0), NTSC.',
    `Open ${base}.nes in Mesen, FCEUX, Nestopia, Everdrive, or a flash cart.`,
    `Open ${base}.html directly in a browser for the HTML5 target.`,
    '',
    'Controls (NES): D-Pad to move, A / B / Up to jump.',
    'Controls (HTML5): arrows or A/D, Space/Z/W/Up to jump, R to restart.',
    '',
    'engine.asm is assembled by the browser 6502 assembler into PRG-ROM.',
    'chr.bin contains 2bpp NES pattern-table data generated from the pixel workshop.',
    'nametable.nam is 960 background tiles plus 64 attribute-table bytes.',
    'palette.pal contains translated hardware 2C02 color indices.',
    '',
    `Generated ${new Date().toISOString()} · ROM checksum ${build.checksum}`,
  ].join('\n'));
  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
  saveAs(blob, `${base}-devkit.zip`);
};
