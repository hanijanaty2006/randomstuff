import { ENTITY_TILE } from '../data/project';
import { hexToRgb } from './nesPalette';
import { LEVEL_H, LEVEL_W, TILE_SIZE, type Entity, type Project } from '../types';

export const makeTileCanvas = (pattern: number[], colors: string[]): HTMLCanvasElement => {
  const canvas = document.createElement('canvas');
  canvas.width = TILE_SIZE;
  canvas.height = TILE_SIZE;
  const ctx = canvas.getContext('2d')!;
  for (let i = 0; i < 64; i++) {
    const colorIndex = pattern[i] ?? 0;
    if (!colorIndex) continue;
    ctx.fillStyle = colors[colorIndex] ?? colors[3] ?? '#fff';
    ctx.fillRect(i % 8, Math.floor(i / 8), 1, 1);
  }
  return canvas;
};

export const makeTileCanvases = (project: Project): HTMLCanvasElement[] =>
  project.tiles.map((tile) => {
    const base = tile.palette * 4;
    const colors = [0, 1, 2, 3].map((i) => project.palette[base + i] ?? '#000000');
    return makeTileCanvas(tile.pattern, colors);
  });

export const drawLevel = (
  ctx: CanvasRenderingContext2D,
  project: Project,
  canvases: HTMLCanvasElement[],
  scale = 1,
) => {
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = project.palette[0] ?? '#5C94FC';
  ctx.fillRect(0, 0, LEVEL_W * TILE_SIZE * scale, LEVEL_H * TILE_SIZE * scale);
  for (let y = 0; y < LEVEL_H; y++) {
    for (let x = 0; x < LEVEL_W; x++) {
      const id = project.level[y * LEVEL_W + x] ?? 0;
      if (!id || !canvases[id]) continue;
      ctx.drawImage(canvases[id], x * TILE_SIZE * scale, y * TILE_SIZE * scale, TILE_SIZE * scale, TILE_SIZE * scale);
    }
  }
};

export const drawEntities = (
  ctx: CanvasRenderingContext2D,
  _project: Project,
  canvases: HTMLCanvasElement[],
  entities: Entity[],
  scale = 1,
  frame = 0,
) => {
  ctx.imageSmoothingEnabled = false;
  entities.forEach((entity) => {
    const tileId = ENTITY_TILE[entity.kind];
    if (!canvases[tileId]) return;
    let x = entity.x * TILE_SIZE * scale;
    let y = entity.y * TILE_SIZE * scale;
    if (entity.kind === 'coin') y += Math.sin(frame / 12 + entity.x) * scale;
    ctx.drawImage(canvases[tileId], x, y, TILE_SIZE * scale, TILE_SIZE * scale);
  });
};

export const solidAt = (project: Project, px: number, py: number) => {
  const x = Math.floor(px / TILE_SIZE);
  const y = Math.floor(py / TILE_SIZE);
  if (x < 0 || x >= LEVEL_W || y < 0 || y >= LEVEL_H) return false;
  const tile = project.tiles[project.level[y * LEVEL_W + x] ?? 0];
  return Boolean(tile?.solid);
};

export const hazardAt = (project: Project, px: number, py: number) => {
  const x = Math.floor(px / TILE_SIZE);
  const y = Math.floor(py / TILE_SIZE);
  if (x < 0 || x >= LEVEL_W || y < 0 || y >= LEVEL_H) return false;
  const tile = project.tiles[project.level[y * LEVEL_W + x] ?? 0];
  return Boolean(tile?.hazard);
};

export const bodyCollides = (project: Project, x: number, y: number, size = 8) =>
  solidAt(project, x, y) ||
  solidAt(project, x + size - 1, y) ||
  solidAt(project, x, y + size - 1) ||
  solidAt(project, x + size - 1, y + size - 1);

export const mix = (hex: string, amount: number) => {
  const [r, g, b] = hexToRgb(hex);
  const target = amount > 0 ? 255 : 0;
  const t = Math.abs(amount);
  return `rgb(${Math.round(r + (target - r) * t)},${Math.round(g + (target - g) * t)},${Math.round(b + (target - b) * t)})`;
};
