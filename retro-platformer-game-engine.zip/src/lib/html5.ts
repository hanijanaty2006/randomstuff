import type { Project } from '../types';

export const generateStandaloneHTML = (project: Project) => {
  const serialized = JSON.stringify({
    name: project.name,
    gravity: project.gravity,
    speed: project.speed,
    jump: project.jump,
    lives: project.lives,
    timeLimit: project.timeLimit,
    palette: project.palette,
    tiles: project.tiles,
    level: project.level,
    entities: project.entities,
  }).replace(/</g, '\\u003c');

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${project.name.replace(/[<>&"]/g, '')} — HTML5 Build</title>
<style>
  * { box-sizing: border-box; }
  body { margin:0; min-height:100vh; display:grid; place-items:center; background:#008080; font-family:Tahoma,"MS Sans Serif",sans-serif; color:#000; }
  .window { background:#c0c0c0; border:2px solid; border-color:#fff #000 #000 #fff; box-shadow:2px 2px 0 #000; padding:3px; }
  .title { background:linear-gradient(90deg,#000080,#1084d0); color:white; font-weight:bold; padding:4px 7px; display:flex; justify-content:space-between; }
  .screen { width:min(768px,92vw); aspect-ratio:256/240; display:block; background:#000; image-rendering:pixelated; border:2px solid; border-color:#808080 #fff #fff #808080; }
  .bar { display:flex; justify-content:space-between; align-items:center; padding:6px 4px 2px; font-size:12px; gap:8px; flex-wrap:wrap; }
  button { font:inherit; background:#c0c0c0; border:2px solid; border-color:#fff #000 #000 #fff; padding:3px 12px; cursor:pointer; }
  button:active { border-color:#000 #fff #fff #000; }
</style>
</head>
<body>
<div class="window">
  <div class="title"><span>${project.name.replace(/[<>&"]/g, '')} — HTML5 EXPORT</span><span>_ □ ×</span></div>
  <canvas id="game" class="screen" width="256" height="240"></canvas>
  <div class="bar"><span>← → / A D move &nbsp;·&nbsp; SPACE / Z / ↑ jump &nbsp;·&nbsp; R restart</span><button id="restart">Restart</button></div>
</div>
<script>
const P = ${serialized};
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const W = 32, H = 30, T = 8;
const entityTile = { player:11, enemy:12, coin:13, power:14, goal:15 };
const tiles = P.tiles.map(tile => {
  const c = document.createElement('canvas'); c.width = 8; c.height = 8;
  const g = c.getContext('2d'); const base = tile.palette * 4;
  for (let i=0;i<64;i++) { const v=tile.pattern[i]; if(v){ g.fillStyle=P.palette[base+v]||'#fff'; g.fillRect(i%8,(i/8)|0,1,1); } }
  return c;
});
const keys = {};
let player, collected, defeated, score, lives, timeLeft, won, frame, lastTick;
function fullReset() {
  const spawn = P.entities.find(e=>e.kind==='player') || {x:2,y:26};
  player = {x:spawn.x*8,y:spawn.y*8,vx:0,vy:0,ground:false};
  collected = new Set(); defeated = new Set(); score = 0; lives = P.lives; timeLeft = P.timeLimit; won = false; frame = 0; lastTick = performance.now();
}
function softReset() { const spawn = P.entities.find(e=>e.kind==='player') || {x:2,y:26}; player = {x:spawn.x*8,y:spawn.y*8,vx:0,vy:0,ground:false}; }
function tileAt(px,py) { const x=(px/T)|0,y=(py/T)|0; if(x<0||x>=W||y<0||y>=H) return null; return P.tiles[P.level[y*W+x]] || null; }
function solid(px,py) { const t=tileAt(px,py); return !!(t && t.solid); }
function hazard(px,py) { const t=tileAt(px,py); return !!(t && t.hazard); }
function body(x,y) { return solid(x,y)||solid(x+7,y)||solid(x,y+7)||solid(x+7,y+7); }
function hit(a,b) { return a.x < b.x+8 && a.x+8 > b.x && a.y < b.y+8 && a.y+8 > b.y; }
function loseLife() { lives--; softReset(); if(lives<=0) fullReset(); }
window.addEventListener('keydown', e => { keys[e.code]=true; if(['ArrowLeft','ArrowRight','ArrowUp','Space'].includes(e.code)) e.preventDefault(); if(e.code==='KeyR') fullReset(); });
window.addEventListener('keyup', e => { keys[e.code]=false; });
document.getElementById('restart').onclick = fullReset;
function update() {
  frame++;
  if(!won) {
    timeLeft = Math.max(0, timeLeft - 1/60);
    player.vx = (keys.ArrowRight||keys.KeyD ? P.speed : 0) - (keys.ArrowLeft||keys.KeyA ? P.speed : 0);
    if((keys.Space||keys.KeyZ||keys.KeyW||keys.ArrowUp) && player.ground) { player.vy = -P.jump; player.ground=false; }
    player.vy = Math.min(5, player.vy + P.gravity);
    const nx = Math.max(0, Math.min(248, player.x + player.vx));
    if(!body(nx,player.y)) player.x = nx;
    const ny = player.y + player.vy;
    if(!body(player.x,ny)) { player.y=ny; player.ground=false; }
    else { if(player.vy>0) { player.y = Math.floor(ny/8)*8; player.ground=true; } player.vy=0; }
    if(hazard(player.x+4,player.y+4)||player.y>232) loseLife();
    P.entities.forEach((e,i) => {
      const box={x:e.x*8,y:e.y*8};
      if(e.kind==='coin' && !collected.has(i) && hit(player,box)) { collected.add(i); score+=100; }
      if(e.kind==='power' && !collected.has(i) && hit(player,box)) { collected.add(i); score+=250; P.jump=Math.min(7,P.jump+0.4); }
      if(e.kind==='enemy' && !defeated.has(i) && hit(player,box)) {
        if(player.vy>0 && player.y+8 < box.y+5) { defeated.add(i); player.vy=-3; score+=200; }
        else loseLife();
      }
      if(e.kind==='goal' && hit(player,box)) { won=true; score+=1000; }
    });
  }
}
function draw() {
  ctx.imageSmoothingEnabled=false;
  ctx.fillStyle=P.palette[0]||'#5C94FC'; ctx.fillRect(0,0,256,240);
  for(let y=0;y<H;y++) for(let x=0;x<W;x++) { const id=P.level[y*W+x]; if(id&&tiles[id]) ctx.drawImage(tiles[id],x*8,y*8); }
  P.entities.forEach((e,i)=>{
    if((e.kind==='coin'||e.kind==='power')&&collected.has(i)) return;
    if(e.kind==='enemy'&&defeated.has(i)) return;
    if(e.kind==='player') return;
    const bob=e.kind==='coin'?Math.sin(frame/12+i)*1.5:0;
    ctx.drawImage(tiles[entityTile[e.kind]],e.x*8,e.y*8+bob);
  });
  ctx.drawImage(tiles[entityTile.player],player.x,player.y);
  ctx.fillStyle='rgba(0,0,0,.45)'; ctx.fillRect(0,0,256,14);
  ctx.fillStyle='#fff'; ctx.font='8px monospace';
  ctx.fillText('SCORE '+String(score).padStart(6,'0'),4,10);
  ctx.fillText('LIVES '+lives,104,10);
  ctx.fillText('TIME '+Math.ceil(timeLeft),170,10);
  ctx.fillText(P.name.slice(0,12),214,10);
  if(won) { ctx.fillStyle='rgba(0,0,0,.72)'; ctx.fillRect(28,82,200,70); ctx.strokeStyle='#FCFC54'; ctx.strokeRect(30,84,196,66); ctx.fillStyle='#FCFC54'; ctx.font='bold 15px monospace'; ctx.textAlign='center'; ctx.fillText('STAGE CLEAR!',128,112); ctx.font='8px monospace'; ctx.fillText('SCORE '+score+'  ·  PRESS R',128,132); ctx.textAlign='left'; }
  if(timeLeft<=0) { ctx.fillStyle='rgba(0,0,0,.72)'; ctx.fillRect(50,96,156,45); ctx.fillStyle='#fff'; ctx.font='bold 12px monospace'; ctx.textAlign='center'; ctx.fillText('TIME UP',128,123); ctx.textAlign='left'; }
}
function loop(now) { if(now-lastTick>=16.6) { update(); lastTick=now; } draw(); requestAnimationFrame(loop); }
fullReset(); requestAnimationFrame(loop);
<\/script>
</body>
</html>`;
};
