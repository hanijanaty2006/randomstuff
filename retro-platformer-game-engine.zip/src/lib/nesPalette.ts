export const NES_PALETTE = [
  0x7c7c7c, 0x0000fc, 0x0000bc, 0x4428bc, 0x940084, 0xa80020, 0xa81000, 0x881400,
  0x503000, 0x007800, 0x006800, 0x005800, 0x004058, 0x000000, 0x000000, 0x000000,
  0xbcbcbc, 0x0078f8, 0x0058f8, 0x6844fc, 0xd800cc, 0xe40058, 0xf83800, 0xe45c10,
  0xac7c00, 0x00b800, 0x00a800, 0x00a844, 0x008888, 0x000000, 0x000000, 0x000000,
  0xf8f8f8, 0x3cbcfc, 0x6888fc, 0x9878f8, 0xf878f8, 0xf85898, 0xf87858, 0xfca044,
  0xf8b800, 0xb8f818, 0x58d854, 0x58f898, 0x00e8d8, 0x787878, 0x000000, 0x000000,
  0xfcfcfc, 0xa4e8fc, 0xb8b8f8, 0xd8b8f8, 0xf8b8f8, 0xf8a4c0, 0xf0d0b0, 0xfce0a8,
  0xf8d878, 0xd8f878, 0xb8f8b8, 0xb8f8d8, 0x00fcfc, 0xf8d8f8, 0x000000, 0x000000,
];

export const hexToRgb = (hex: string): [number, number, number] => {
  const clean = hex.replace('#', '');
  const full = clean.length === 3 ? clean.split('').map((c) => c + c).join('') : clean;
  const value = Number.parseInt(full, 16);
  return [(value >> 16) & 255, (value >> 8) & 255, value & 255];
};

export const rgbToHex = (r: number, g: number, b: number) =>
  `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`;

export const nearestNesColor = (hex: string) => {
  const [r, g, b] = hexToRgb(hex);
  let best = 0;
  let bestScore = Number.POSITIVE_INFINITY;
  NES_PALETTE.forEach((packed, index) => {
    const pr = (packed >> 16) & 255;
    const pg = (packed >> 8) & 255;
    const pb = packed & 255;
    const score = (r - pr) ** 2 + (g - pg) ** 2 + (b - pb) ** 2;
    if (score < bestScore) {
      bestScore = score;
      best = index;
    }
  });
  return { index: best, hex: rgbToHex((NES_PALETTE[best] >> 16) & 255, (NES_PALETTE[best] >> 8) & 255, NES_PALETTE[best] & 255) };
};

export const nesPaletteBytes = (palette: string[]) => {
  const result: number[] = [];
  for (let group = 0; group < 4; group++) {
    for (let i = 0; i < 4; i++) result.push(nearestNesColor(palette[group * 4 + i] ?? '#000000').index);
  }
  // The four sprite palettes mirror the four background palettes.
  for (let group = 0; group < 4; group++) {
    for (let i = 0; i < 4; i++) result.push(nearestNesColor(palette[group * 4 + i] ?? '#000000').index);
  }
  return result.slice(0, 32);
};
