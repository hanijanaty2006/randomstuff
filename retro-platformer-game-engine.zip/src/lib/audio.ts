import * as Tone from 'tone';

const notes: Record<string, { pitches: string[]; duration: number; type: 'square' | 'triangle' | 'sawtooth' }> = {
  click: { pitches: ['A4'], duration: 0.035, type: 'square' },
  paint: { pitches: ['E5'], duration: 0.025, type: 'square' },
  success: { pitches: ['C5', 'E5', 'G5', 'C6'], duration: 0.09, type: 'square' },
  build: { pitches: ['C4', 'G4', 'C5', 'E5', 'G5'], duration: 0.08, type: 'square' },
  error: { pitches: ['A3', 'F3'], duration: 0.14, type: 'sawtooth' },
  jump: { pitches: ['C5', 'G5'], duration: 0.07, type: 'square' },
  coin: { pitches: ['E6', 'B6'], duration: 0.06, type: 'square' },
  hurt: { pitches: ['G3', 'C3'], duration: 0.12, type: 'triangle' },
  win: { pitches: ['C5', 'E5', 'G5', 'C6', 'E6'], duration: 0.12, type: 'square' },
};

export const playSfx = async (name: keyof typeof notes | string) => {
  const config = notes[name] ?? notes.click;
  try {
    await Tone.start();
    const synth = new Tone.Synth({
      oscillator: { type: config.type },
      envelope: { attack: 0.001, decay: 0.02, sustain: 0.05, release: 0.08 },
      volume: -20,
    }).toDestination();
    config.pitches.forEach((pitch, index) => {
      synth.triggerAttackRelease(pitch, config.duration, Tone.now() + index * (config.duration + 0.015));
    });
    window.setTimeout(() => synth.dispose(), config.pitches.length * 140 + 400);
  } catch {
    // Audio can be blocked before a user gesture; the visual app remains fully functional.
  }
};
