import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent, type ReactNode } from 'react';
import clsx from 'clsx';
import hotkeys from 'hotkeys-js';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster, toast } from 'sonner';
import { Code2, Cpu, Gamepad2, Layers, Palette, Play, Terminal, Monitor } from 'lucide-react';
import { DesktopIcons, MenuBar, StatusBar, Taskbar, TitleBar, Toolbar, type MenuAction, type MenuGroup, type TaskbarActions } from './components/WinChrome';
import { LevelWorkspace } from './components/LevelEditor';
import { SpriteWorkshop } from './components/SpriteWorkshop';
import { Html5Preview, NesEmulator } from './components/Runtimes';
import { RomInspector, SourceViewer } from './components/Viewers';
import { BuildConsole, ProjectExplorer, PropertiesPanel } from './components/SidePanels';
import { Dialogs } from './components/Dialogs';
import { makeTileCanvases } from './lib/render';
import { buildNESROM, type BuildResult } from './lib/nes';
import { exportDevKit, exportHTML5, exportProjectJSON, exportROM } from './lib/exporters';
import { playSfx } from './lib/audio';
import { useStudio } from './store/useStudio';
import type { Project, TabId } from './types';

type WindowMode = 'normal' | 'maximized' | 'minimized' | 'closed';

const TABS: { id: TabId; label: string; icon: ReactNode }[] = [
  { id: 'level', label: 'Level Editor', icon: <Layers size={13} /> },
  { id: 'sprites', label: 'Pixel Workshop', icon: <Palette size={13} /> },
  { id: 'preview', label: 'HTML5 Playtest', icon: <Play size={13} /> },
  { id: 'emulator', label: 'NES Emulator', icon: <Gamepad2 size={13} /> },
  { id: 'source', label: 'Source / Build', icon: <Code2 size={13} /> },
  { id: 'rom', label: 'ROM Inspector', icon: <Cpu size={13} /> },
];

export default function App() {
  const project = useStudio((s) => s.project);
  const activeTab = useStudio((s) => s.activeTab);
  const consoleOpen = useStudio((s) => s.consoleOpen);
  const needsBuild = useStudio((s) => s.needsBuild);
  const canUndo = useStudio((s) => s.past.length > 0);
  const canRedo = useStudio((s) => s.future.length > 0);
  const setTab = useStudio((s) => s.setTab);
  const setDialog = useStudio((s) => s.setDialog);
  const toggleConsole = useStudio((s) => s.toggleConsole);
  const clearLevel = useStudio((s) => s.clearLevel);
  const toggleGrid = useStudio((s) => s.toggleGrid);
  const toggleCollision = useStudio((s) => s.toggleCollision);
  const markBuilt = useStudio((s) => s.markBuilt);
  const markSaved = useStudio((s) => s.markSaved);
  const replaceProject = useStudio((s) => s.replaceProject);
  const [build, setBuild] = useState<BuildResult>(() => buildNESROM(useStudio.getState().project));
  const buildRef = useRef(build);
  const [windowMode, setWindowMode] = useState<WindowMode>('normal');
  const fileRef = useRef<HTMLInputElement>(null);
  const canvases = useMemo(() => makeTileCanvases(project), [project]);

  const assemble = useCallback((announce = true) => {
    const state = useStudio.getState();
    const started = performance.now();
    try {
      const result = buildNESROM(state.project);
      buildRef.current = result;
      setBuild(result);
      markBuilt();
      state.addLog(`Pass 1/2: resolving symbols · ${result.assemblyResult.lineCount} statements`, 'info');
      state.addLog(`Pass 2/2: emitting 6502 opcodes · RESET $${result.assemblyResult.symbols.reset?.toString(16).toUpperCase()}`, 'info');
      state.addLog(`Encoding CHR-ROM: ${state.project.tiles.length} tiles × 16 bytes → 8 KiB`, 'ok');
      state.addLog(`Linking nametable: 960 tiles + 64 attribute bytes · ${state.project.entities.length} OAM objects`, 'ok');
      state.addLog(`iNES image ready: ${result.rom.length} bytes · checksum ${result.checksum} · ${(performance.now() - started).toFixed(1)} ms`, 'ok');
      result.warnings.forEach((warning) => state.addLog(`WARNING: ${warning}`, 'warn'));
      if (announce) { toast.success(`Cartridge built · ${result.rom.length.toLocaleString()} bytes`); playSfx('build'); }
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown assembler error';
      state.addLog(`ASSEMBLY FAILED: ${message}`, 'error');
      toast.error(`Build failed: ${message}`);
      playSfx('error');
      return null;
    }
  }, [markBuilt]);

  const ensureBuild = useCallback(() => {
    if (useStudio.getState().needsBuild) return assemble(false) ?? buildRef.current;
    return buildRef.current;
  }, [assemble]);

  const saveProject = useCallback(() => {
    exportProjectJSON(useStudio.getState().project);
    markSaved();
    toast.success('Project JSON downloaded');
    playSfx('success');
  }, [markSaved]);

  const openProjectFile = useCallback(async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as Project;
      if (!Array.isArray(parsed.level) || !Array.isArray(parsed.tiles) || !Array.isArray(parsed.entities)) throw new Error('Missing level, tiles or entities array');
      replaceProject(parsed);
      toast.success(`Opened ${parsed.name}`);
      playSfx('success');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Invalid project file');
      playSfx('error');
    } finally { event.target.value = ''; }
  }, [replaceProject]);

  const handleAction = useCallback((action: string) => {
    const state = useStudio.getState();
    switch (action) {
      case 'new': setDialog('new'); break;
      case 'open': fileRef.current?.click(); break;
      case 'save': saveProject(); break;
      case 'library': setDialog('library'); break;
      case 'rom': setTab('rom'); break;
      case 'html': exportHTML5(state.project); toast.success('Standalone HTML5 game downloaded'); playSfx('success'); break;
      case 'nes': exportROM(state.project, ensureBuild()); toast.success('Playable .nes ROM downloaded'); playSfx('success'); break;
      case 'zip': {
        const result = ensureBuild();
        void toast.promise(exportDevKit(state.project, result), { loading: 'Packaging development kit…', success: 'Dev kit ZIP downloaded', error: 'Could not create ZIP' });
        playSfx('success');
        break;
      }
      case 'build': assemble(true); break;
      case 'preview': setTab('preview'); break;
      case 'emulator': ensureBuild(); setTab('emulator'); break;
      case 'source': setTab('source'); break;
      case 'inspector': setTab('rom'); break;
      case 'undo': state.undo(); break;
      case 'redo': state.redo(); break;
      case 'grid': toggleGrid(); break;
      case 'collision': toggleCollision(); break;
      case 'clear': clearLevel(); toast.info('Level cleared'); break;
      case 'resetDemo': state.resetProject(); toast.info('Demo project restored'); break;
      case 'settings': setDialog('settings'); break;
      case 'help': setDialog('help'); break;
      case 'about': setDialog('about'); break;
      default: break;
    }
  }, [assemble, clearLevel, ensureBuild, saveProject, setDialog, setTab, toggleCollision, toggleGrid]);

  useEffect(() => {
    const previousFilter = hotkeys.filter;
    hotkeys.filter = (event) => {
      const tag = (event.target as HTMLElement)?.tagName;
      return !['INPUT', 'TEXTAREA', 'SELECT'].includes(tag ?? '');
    };
    const keys = 'b,e,f,r,v,d,g,1,2,3,4,ctrl+z,ctrl+y,ctrl+s,ctrl+o,ctrl+n,ctrl+b,f1,f5,f6';
    const handler = (event: KeyboardEvent, binding: { key: string }) => {
      const state = useStudio.getState();
      const key = binding.key.toLowerCase();
      if (['ctrl+s', 'ctrl+o', 'ctrl+n', 'ctrl+b', 'ctrl+z', 'ctrl+y', 'f1', 'f5', 'f6'].includes(key)) event.preventDefault();
      const inGame = state.activeTab === 'preview' || state.activeTab === 'emulator';
      if (!inGame) {
        if (key === 'b') state.setTool('brush');
        else if (key === 'e') state.setTool('eraser');
        else if (key === 'f') state.setTool('fill');
        else if (key === 'r') state.setTool('rect');
        else if (key === 'v') state.setTool('select');
        else if (key === 'd') state.setTool('entity');
        else if (key === 'g') state.toggleGrid();
        else if (['1', '2', '3', '4'].includes(key)) state.setZoom(Number(key));
      }
      if (key === 'ctrl+z') state.undo();
      else if (key === 'ctrl+y') state.redo();
      else if (key === 'ctrl+s') handleAction('save');
      else if (key === 'ctrl+o') handleAction('open');
      else if (key === 'ctrl+n') handleAction('new');
      else if (key === 'ctrl+b') handleAction('build');
      else if (key === 'f1') handleAction('help');
      else if (key === 'f5') handleAction('preview');
      else if (key === 'f6') handleAction('build');
    };
    hotkeys(keys, handler);
    return () => { hotkeys.unbind(keys, handler); hotkeys.filter = previousFilter; };
  }, [handleAction]);

  const sep = (): MenuAction => ({ label: '', separator: true });
  const menus: MenuGroup[] = [
    { label: 'File', items: [
      { label: 'New Cartridge…', shortcut: 'Ctrl+N', action: () => handleAction('new') },
      { label: 'Open Project JSON…', shortcut: 'Ctrl+O', action: () => handleAction('open') },
      { label: 'Save Project JSON', shortcut: 'Ctrl+S', action: () => handleAction('save') },
      { label: 'Local Cartridge Library…', action: () => handleAction('library') },
      sep(),
      { label: 'Export real .nes ROM', action: () => handleAction('nes') },
      { label: 'Export standalone HTML5', action: () => handleAction('html') },
      { label: 'Export Development Kit (.zip)', action: () => handleAction('zip') },
      sep(),
      { label: 'Restore Demo Project', action: () => handleAction('resetDemo') },
    ] },
    { label: 'Edit', items: [
      { label: 'Undo', shortcut: 'Ctrl+Z', action: () => handleAction('undo'), disabled: !canUndo },
      { label: 'Redo', shortcut: 'Ctrl+Y', action: () => handleAction('redo'), disabled: !canRedo },
      sep(),
      { label: 'Toggle Tile Grid', shortcut: 'G', action: () => handleAction('grid') },
      { label: 'Toggle Collision Overlay', action: () => handleAction('collision') },
      { label: 'Clear Level', action: () => handleAction('clear') },
      sep(),
      { label: 'Game Properties…', action: () => handleAction('settings') },
    ] },
    { label: 'Level', items: [
      { label: 'Level Editor', action: () => setTab('level') },
      { label: 'Pixel / CHR Workshop', action: () => setTab('sprites') },
      { label: 'Object Inspector', action: () => setTab('level') },
      sep(),
      { label: 'Open Build Console', action: () => { toggleConsole(); } },
      { label: 'Source Browser', action: () => setTab('source') },
    ] },
    { label: 'Build', items: [
      { label: 'Build Cartridge', shortcut: 'F6', action: () => handleAction('build') },
      { label: 'Boot NES ROM', action: () => handleAction('emulator') },
      { label: 'HTML5 Playtest', shortcut: 'F5', action: () => handleAction('preview') },
      sep(),
      { label: 'ROM Inspector', action: () => handleAction('inspector') },
      { label: 'Download .nes', action: () => handleAction('nes') },
      { label: 'Download Dev Kit', action: () => handleAction('zip') },
    ] },
    { label: 'Help', items: [
      { label: 'Keyboard Shortcuts', shortcut: 'F1', action: () => handleAction('help') },
      { label: 'About NES Maker Studio 98', action: () => handleAction('about') },
    ] },
  ];

  const taskbarActions: TaskbarActions = {
    restore: () => setWindowMode('normal'),
    newProject: () => handleAction('new'),
    build: () => handleAction('build'),
    preview: () => handleAction('preview'),
    emulator: () => handleAction('emulator'),
    about: () => handleAction('about'),
    help: () => handleAction('help'),
  };
  const windowVisible = windowMode === 'normal' || windowMode === 'maximized';

  return (
    <div className="desktop">
      <div className="desktop-wallpaper-lines" />
      <DesktopIcons onOpen={(tab) => { setTab(tab as TabId); setWindowMode('normal'); }} />
      {!windowVisible && (
        <div className="desktop-message">
          <h1>NES Maker Studio 98</h1>
          <p>{windowMode === 'minimized' ? 'Studio window minimized to the taskbar.' : 'Studio window closed. Your project is still in memory.'}</p>
          <button className="win-button primary" onClick={() => setWindowMode('normal')}><Monitor size={13} /> Restore Studio</button>
        </div>
      )}
      {windowVisible && (
        <div className={clsx('app-window', windowMode === 'maximized' && 'maximized')}>
          <TitleBar maximized={windowMode === 'maximized'} onMaximize={() => setWindowMode(windowMode === 'maximized' ? 'normal' : 'maximized')} onMinimize={() => setWindowMode('minimized')} onClose={() => setWindowMode('closed')} />
          <MenuBar groups={menus} />
          <Toolbar onAction={handleAction} />
          <div className="workspace">
            <ProjectExplorer />
            <div className="center-column">
              <div className="tab-strip">
                {TABS.map((tab) => (
                  <button key={tab.id} className={clsx('win-tab', activeTab === tab.id && 'active')} onClick={() => { if (['emulator', 'rom', 'source'].includes(tab.id)) ensureBuild(); setTab(tab.id); playSfx('click'); }}>
                    {tab.icon}<span>{tab.label}</span>
                  </button>
                ))}
                <div className="tab-spacer" />
                <span className="tab-build-state"><span className={clsx('status-led', needsBuild ? 'amber' : 'green')} /> {needsBuild ? 'STALE' : 'ROM READY'}</span>
              </div>
              <div className="tab-content">
                <AnimatePresence mode="wait">
                  <motion.div key={activeTab} className="tab-pane" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.13 }}>
                    {activeTab === 'level' && <LevelWorkspace project={project} canvases={canvases} />}
                    {activeTab === 'sprites' && <SpriteWorkshop project={project} />}
                    {activeTab === 'preview' && <Html5Preview project={project} canvases={canvases} />}
                    {activeTab === 'emulator' && <NesEmulator rom={build.rom} project={project} />}
                    {activeTab === 'source' && <SourceViewer project={project} build={build} />}
                    {activeTab === 'rom' && <RomInspector project={project} build={build} canvases={canvases} />}
                  </motion.div>
                </AnimatePresence>
              </div>
              {consoleOpen ? <BuildConsole build={build} /> : (
                <button className="console-collapsed" onClick={toggleConsole}><Terminal size={12} /> Build console hidden · click to expand <span>▲</span></button>
              )}
            </div>
            <PropertiesPanel project={project} build={build} />
          </div>
          <StatusBar />
        </div>
      )}
      <Taskbar actions={taskbarActions} windowVisible={windowVisible} />
      <Dialogs />
      <input ref={fileRef} type="file" accept="application/json,.json" style={{ display: 'none' }} onChange={openProjectFile} />
      <Toaster position="top-right" toastOptions={{ className: 'win-toast' }} />
    </div>
  );
}
