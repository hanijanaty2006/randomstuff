export const LEVEL_W = 32;
export const LEVEL_H = 30;
export const TILE_SIZE = 8;
export const SCREEN_W = 256;
export const SCREEN_H = 240;

export type Tool = 'brush' | 'eraser' | 'fill' | 'rect' | 'entity' | 'select';
export type EntityKind = 'player' | 'enemy' | 'coin' | 'power' | 'goal';
export type TabId = 'level' | 'sprites' | 'preview' | 'emulator' | 'source' | 'rom';
export type DialogId = 'about' | 'library' | 'new' | 'help' | 'settings' | null;

export interface TileDef {
  id: number;
  name: string;
  group: 'terrain' | 'decor' | 'actor' | 'pickup';
  solid: boolean;
  hazard: boolean;
  palette: number;
  pattern: number[];
}

export interface Entity {
  id: string;
  kind: EntityKind;
  x: number;
  y: number;
}

export interface Project {
  name: string;
  author: string;
  version: string;
  description: string;
  target: 'NES' | 'HTML5' | 'Dual target';
  gravity: number;
  speed: number;
  jump: number;
  lives: number;
  timeLimit: number;
  palette: string[];
  tiles: TileDef[];
  level: number[];
  entities: Entity[];
  updatedAt: number;
}

export interface BuildLog {
  id: string;
  time: string;
  level: 'info' | 'ok' | 'warn' | 'error';
  message: string;
}

export interface Cell { x: number; y: number }

export interface SaveSlot {
  id: string;
  name: string;
  updatedAt: number;
  data: Project;
}
