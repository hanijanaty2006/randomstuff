import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import { cloneDeep } from 'lodash-es';
import { nanoid } from 'nanoid';
import type { Draft } from 'immer';
import { blankProject, createDefaultProject } from '../data/project';
import { LEVEL_H, LEVEL_W, type BuildLog, type Cell, type DialogId, type EntityKind, type Project, type TabId, type TileDef, type Tool } from '../types';

interface StudioState {
  project: Project;
  past: Project[];
  future: Project[];
  tool: Tool;
  selectedTile: number;
  selectedEntityKind: EntityKind;
  selectedEntityId: string | null;
  paletteSlot: number;
  zoom: number;
  showGrid: boolean;
  showCollision: boolean;
  activeTab: TabId;
  dialog: DialogId;
  consoleOpen: boolean;
  hover: Cell | null;
  statusMessage: string;
  dirty: boolean;
  needsBuild: boolean;
  lastSavedAt: number | null;
  logs: BuildLog[];
  buildCount: number;
  commit: (recipe: (project: Draft<Project>) => void) => void;
  undo: () => void;
  redo: () => void;
  setTool: (tool: Tool) => void;
  setSelectedTile: (id: number) => void;
  setSelectedEntityKind: (kind: EntityKind) => void;
  selectEntity: (id: string | null) => void;
  setPaletteSlot: (slot: number) => void;
  setZoom: (zoom: number) => void;
  toggleGrid: () => void;
  toggleCollision: () => void;
  setTab: (tab: TabId) => void;
  setDialog: (dialog: DialogId) => void;
  toggleConsole: () => void;
  setHover: (cell: Cell | null) => void;
  setStatus: (message: string) => void;
  setLevelCells: (cells: Cell[], tileId?: number) => void;
  floodFill: (x: number, y: number, tileId?: number) => void;
  clearLevel: () => void;
  addEntity: (kind: EntityKind, x: number, y: number) => void;
  removeEntityAt: (x: number, y: number) => void;
  selectEntityAt: (x: number, y: number) => void;
  moveEntity: (id: string, x: number, y: number) => void;
  deleteEntity: (id: string) => void;
  setTilePixel: (tileId: number, pixel: number, value: number) => void;
  clearTile: (tileId: number) => void;
  setPaletteColor: (index: number, color: string) => void;
  setTileMeta: (tileId: number, patch: Partial<Pick<TileDef, 'name' | 'solid' | 'hazard' | 'palette'>>) => void;
  updateProject: (patch: Partial<Project>) => void;
  replaceProject: (project: Project) => void;
  newProject: () => void;
  resetProject: () => void;
  addLog: (message: string, level?: BuildLog['level']) => void;
  clearLogs: () => void;
  markSaved: () => void;
  markBuilt: () => void;
}

const time = () => new Date().toLocaleTimeString('en-US', { hour12: false });

const initialLogs: BuildLog[] = [
  { id: nanoid(6), time: time(), level: 'ok', message: 'NES Maker Studio 98 initialized · NROM-256 toolchain online' },
  { id: nanoid(6), time: time(), level: 'info', message: 'Loaded ca65-style assembler, CHR encoder, jsnes core and HTML5 runtime' },
  { id: nanoid(6), time: time(), level: 'info', message: 'Ready. Press BUILD CARTRIDGE to assemble a playable .nes image.' },
];

export const useStudio = create<StudioState>()(immer((set, get) => {
  const commit = (recipe: (project: Draft<Project>) => void) => set((state) => {
    state.past.push(cloneDeep(state.project));
    if (state.past.length > 50) state.past.shift();
    state.future = [];
    recipe(state.project);
    state.project.updatedAt = Date.now();
    state.dirty = true;
    state.needsBuild = true;
  });

  return {
    project: createDefaultProject(),
    past: [],
    future: [],
    tool: 'brush',
    selectedTile: 1,
    selectedEntityKind: 'coin',
    selectedEntityId: null,
    paletteSlot: 2,
    zoom: 2,
    showGrid: true,
    showCollision: false,
    activeTab: 'level',
    dialog: null,
    consoleOpen: true,
    hover: null,
    statusMessage: 'Ready',
    dirty: false,
    needsBuild: false,
    lastSavedAt: null,
    logs: initialLogs,
    buildCount: 0,
    commit,
    undo: () => set((state) => {
      const previous = state.past.pop();
      if (!previous) return;
      state.future.push(cloneDeep(state.project));
      state.project = cloneDeep(previous);
      state.dirty = true;
      state.needsBuild = true;
      state.statusMessage = 'Undo';
    }),
    redo: () => set((state) => {
      const next = state.future.pop();
      if (!next) return;
      state.past.push(cloneDeep(state.project));
      state.project = cloneDeep(next);
      state.dirty = true;
      state.needsBuild = true;
      state.statusMessage = 'Redo';
    }),
    setTool: (tool) => set((state) => { state.tool = tool; state.statusMessage = `${tool.toUpperCase()} tool selected`; }),
    setSelectedTile: (id) => set((state) => { state.selectedTile = id; state.selectedEntityId = null; state.statusMessage = `Tile ${id} selected`; }),
    setSelectedEntityKind: (kind) => set((state) => { state.selectedEntityKind = kind; state.tool = 'entity'; state.statusMessage = `${kind} placement tool`; }),
    selectEntity: (id) => set((state) => { state.selectedEntityId = id; }),
    setPaletteSlot: (slot) => set((state) => { state.paletteSlot = slot; }),
    setZoom: (zoom) => set((state) => { state.zoom = Math.max(1, Math.min(4, zoom)); }),
    toggleGrid: () => set((state) => { state.showGrid = !state.showGrid; }),
    toggleCollision: () => set((state) => { state.showCollision = !state.showCollision; }),
    setTab: (tab) => set((state) => { state.activeTab = tab; state.statusMessage = `${tab} workspace`; }),
    setDialog: (dialog) => set((state) => { state.dialog = dialog; }),
    toggleConsole: () => set((state) => { state.consoleOpen = !state.consoleOpen; }),
    setHover: (cell) => set((state) => { state.hover = cell; }),
    setStatus: (message) => set((state) => { state.statusMessage = message; }),
    setLevelCells: (cells, tileId) => commit((project) => {
      const id = tileId ?? get().selectedTile;
      cells.forEach(({ x, y }) => {
        if (x >= 0 && x < LEVEL_W && y >= 0 && y < LEVEL_H) project.level[y * LEVEL_W + x] = id;
      });
    }),
    floodFill: (x, y, tileId) => commit((project) => {
      const replacement = tileId ?? get().selectedTile;
      const from = project.level[y * LEVEL_W + x];
      if (from === replacement || x < 0 || x >= LEVEL_W || y < 0 || y >= LEVEL_H) return;
      const queue: Cell[] = [{ x, y }];
      const seen = new Set<number>();
      while (queue.length) {
        const cell = queue.pop()!;
        const index = cell.y * LEVEL_W + cell.x;
        if (cell.x < 0 || cell.x >= LEVEL_W || cell.y < 0 || cell.y >= LEVEL_H || seen.has(index)) continue;
        if (project.level[index] !== from) continue;
        seen.add(index);
        project.level[index] = replacement;
        queue.push({ x: cell.x + 1, y: cell.y }, { x: cell.x - 1, y: cell.y }, { x: cell.x, y: cell.y + 1 }, { x: cell.x, y: cell.y - 1 });
      }
    }),
    clearLevel: () => commit((project) => { project.level = new Array(LEVEL_W * LEVEL_H).fill(0); }),
    addEntity: (kind, x, y) => {
      const created = { id: nanoid(8), kind, x, y };
      commit((project) => {
        if (kind === 'player') project.entities = project.entities.filter((e) => e.kind !== 'player');
        if (project.entities.length >= 31) project.entities.shift();
        project.entities.push(created);
      });
      set((state) => {
        state.selectedEntityId = created.id;
        state.tool = 'entity';
      });
    },
    removeEntityAt: (x, y) => commit((project) => {
      const idx = project.entities.map((e, i) => ({ e, i })).reverse().find(({ e }) => e.x === x && e.y === y)?.i;
      if (idx !== undefined) project.entities.splice(idx, 1);
    }),
    selectEntityAt: (x, y) => set((state) => {
      const match = [...state.project.entities].reverse().find((e) => e.x === x && e.y === y);
      state.selectedEntityId = match?.id ?? null;
      state.statusMessage = match ? `${match.kind.toUpperCase()} at ${x},${y}` : 'No entity at cursor';
    }),
    moveEntity: (id, x, y) => commit((project) => {
      const entity = project.entities.find((e) => e.id === id);
      if (entity) { entity.x = x; entity.y = y; }
    }),
    deleteEntity: (id) => commit((project) => { project.entities = project.entities.filter((e) => e.id !== id); }),
    setTilePixel: (tileId, pixel, value) => commit((project) => {
      const tile = project.tiles[tileId];
      if (tile && pixel >= 0 && pixel < 64) tile.pattern[pixel] = Math.max(0, Math.min(3, value));
    }),
    clearTile: (tileId) => commit((project) => {
      const tile = project.tiles[tileId];
      if (tile) tile.pattern = new Array(64).fill(0);
    }),
    setPaletteColor: (index, color) => commit((project) => {
      if (index >= 0 && index < 16) project.palette[index] = color;
    }),
    setTileMeta: (tileId, patch) => commit((project) => {
      const tile = project.tiles[tileId];
      if (tile) Object.assign(tile, patch);
    }),
    updateProject: (patch) => commit((project) => { Object.assign(project, patch); }),
    replaceProject: (project) => set((state) => {
      state.past.push(cloneDeep(state.project));
      state.future = [];
      state.project = cloneDeep(project);
      state.selectedEntityId = null;
      state.dirty = true;
      state.needsBuild = true;
      state.statusMessage = `Opened ${project.name}`;
    }),
    newProject: () => set((state) => {
      state.past.push(cloneDeep(state.project));
      state.future = [];
      state.project = blankProject();
      state.selectedEntityId = null;
      state.dirty = true;
      state.needsBuild = true;
      state.statusMessage = 'New cartridge created';
    }),
    resetProject: () => set((state) => {
      state.past.push(cloneDeep(state.project));
      state.future = [];
      state.project = createDefaultProject();
      state.selectedEntityId = null;
      state.dirty = true;
      state.needsBuild = true;
      state.statusMessage = 'Demo project restored';
    }),
    addLog: (message, level = 'info') => set((state) => {
      state.logs.push({ id: nanoid(6), time: time(), level, message });
      if (state.logs.length > 150) state.logs.shift();
    }),
    clearLogs: () => set((state) => { state.logs = []; }),
    markSaved: () => set((state) => { state.dirty = false; state.lastSavedAt = Date.now(); state.statusMessage = 'Project saved'; }),
    markBuilt: () => set((state) => { state.needsBuild = false; state.buildCount += 1; }),
  };
}));
